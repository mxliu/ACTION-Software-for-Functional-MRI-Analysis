from PyQt5 import QtWidgets
from PyQt5.QtWidgets import *
from PyQt5.uic import loadUi
from PyQt5.QtCore import QCoreApplication
import numpy as np
from random import randrange
from scipy.signal import resample
import os
import dill

class Ui_BOLD_Aug(QDialog):
    def __init__(self):
        super(Ui_BOLD_Aug, self).__init__()

        loadUi('./ui2/Dialog_Signal_Aug.ui', self)
        self.pushButton_MDA.setEnabled(False)

        self.pushButton_Browse_Data.clicked.connect(self.BrowseData_load)
        self.pushButton_MDA.clicked.connect(self.BrowseAlg_load)
        self.radioButton_upsample.toggled.connect(self.update_Up_Text_State)
        self.radioButton_downsample.toggled.connect(self.update_Dw_Text_State)
        self.radioButton_slicing.toggled.connect(self.update_Sl_Text_State)
        self.radioButton_jittering.toggled.connect(self.update_Ji_Text_State)
        self.radioButton_MDA.toggled.connect(self.enable_pushButton_MDA)
        self.lineEdit_Upsample_Ratio.textChanged.connect(self.checkInput_Up)
        self.lineEdit_Downsample_Ratio.textChanged.connect(self.checkInput_Dw)
        self.lineEdit_Slicing_Percentage.textChanged.connect(self.checkInput_Sl)
        self.lineEdit_Jittering_Ratio.textChanged.connect(self.checkInput_NJ)
        self.pushButton_Browse_SaveDir.clicked.connect(self.BrowseSaveDir)
        self.pushButton_CreateData.clicked.connect(self.CreateData)
        self.pushButton_Help.clicked.connect(self.Help)
        self.Clear.clicked.connect(self.CleaR)



    def BrowseData_load(self):
        file_name = QFileDialog.getOpenFileName(self, 'Open File', 'materials',
                                                'matrix data, with shape (S, N, T) (*.npy)',
                                                options=QtWidgets.QFileDialog.DontUseNativeDialog)
        self.lineEdit_Browse_Data.setText(file_name[0])

    def BrowseSaveDir(self):
        folder_name = QFileDialog.getExistingDirectory(self, 'Select Directory',
                                                       options=QtWidgets.QFileDialog.DontUseNativeDialog)
        self.lineEdit_Browse_SaveDir.setText(folder_name)

    def BrowseAlg_load(self):
        # Please ensure that all dependencies required by the function are properly encapsulated within the pkl file by 'dill' and correctly installed on the device.
        alg_name = QFileDialog.getOpenFileName(self, 'Open File', 'algorithm',
                                                'defined function, with input shape (S, N, T) and output shape (S, N, _ ) (*.pkl)',
                                                options=QtWidgets.QFileDialog.DontUseNativeDialog)
        self.lineEdit_load_MDA.setText(alg_name[0])

    def update_Up_Text_State(self, checked):
        if not checked:
            self.lineEdit_Upsample_Ratio.setReadOnly(True)
            self.lineEdit_Upsample_Ratio.setStyleSheet("color: gray")
        else:
            self.lineEdit_Upsample_Ratio.setReadOnly(False)
            self.lineEdit_Upsample_Ratio.setStyleSheet("color: black")

    def update_Dw_Text_State(self, checked):
        if not checked:
            self.lineEdit_Downsample_Ratio.setReadOnly(True)
            self.lineEdit_Downsample_Ratio.setStyleSheet("color: gray")
        else:
            self.lineEdit_Downsample_Ratio.setReadOnly(False)
            self.lineEdit_Downsample_Ratio.setStyleSheet("color: black")

    def update_Sl_Text_State(self, checked):
        if not checked:
            self.lineEdit_Slicing_Percentage.setReadOnly(True)
            self.lineEdit_Slicing_Percentage.setStyleSheet("color: gray")
        else:
            self.lineEdit_Slicing_Percentage.setReadOnly(False)
            self.lineEdit_Slicing_Percentage.setStyleSheet("color: black")

    def update_Ji_Text_State(self, checked):
        if not checked:
            self.lineEdit_Jittering_Ratio.setReadOnly(True)
            self.lineEdit_Jittering_Ratio.setStyleSheet("color: gray")
        else:
            self.lineEdit_Jittering_Ratio.setReadOnly(False)
            self.lineEdit_Jittering_Ratio.setStyleSheet("color: black")

    def checkInput_Up(self, text):
        if text.strip() == "":
            return
        try:
            value = float(text)
            if value < 0 or value > 1:
                raise ValueError("Input value must be between 0 and 1.")
        except ValueError as e:
            QMessageBox.critical(self, "Error", str(e))
            self.lineEdit_Upsample_Ratio.clear()

    def checkInput_Dw(self, text):
        if text.strip() == "":
            return
        try:
            value = float(text)
            if value < 0 or value > 1:
                raise ValueError("Input value must be between 0 and 1.")
        except ValueError as e:
            QMessageBox.critical(self, "Error", str(e))
            self.lineEdit_Downsample_Ratio.clear()

    def Load_file(self, file_name):
        data = np.load(file_name)
        return data

    def checkInput_Sl(self, text):
        if text.strip() == "":
            return
        try:
            value = float(text)
            if value < 0 or value > 1:
                raise ValueError("Input value must be between 0 and 1.")
        except ValueError as e:
            QMessageBox.critical(self, "Error", str(e))
            self.lineEdit_Slicing_Percentage.clear()

    def checkInput_NJ(self, text):
        if text.strip() == "":
            return
        try:
            value = float(text)
            if value < 0:
                raise ValueError("Input value must be non-negative.")
        except ValueError as e:
            QMessageBox.critical(self, "Error", str(e))
            self.lineEdit_Jittering_Ratio.clear()

    def enable_pushButton_MDA(self, checked):
        if checked:
            self.pushButton_MDA.setEnabled(True)
        else:
            self.pushButton_MDA.setEnabled(False)

    def CreateData(self):
        file_name = self.lineEdit_Browse_Data.text()
        if not file_name:
            QMessageBox.critical(self, "Error", "Input is empty.")
            return
        data = self.Load_file(file_name)
        if data.ndim != 3:
            QMessageBox.critical(self, "Error", "Input shape error. Data must be a 3-dimensional matrix with a shape of (S, N, T), "
                                                "where S is the number of subjects, N is the number of nodes, and T is the time points. "
                                                "Please check your input dimensions.")
            self.lineEdit_Browse_Data.clear()
            return

        if self.lineEdit_Browse_SaveDir.text() == "": save_dir = './results'
        else: save_dir = self.lineEdit_Browse_SaveDir.text()

        if self.radioButton_upsample.isChecked() and self.lineEdit_Upsample_Ratio.text() == "":
            self.lineEdit_Upsample_Ratio.setText("1.0")
        if self.radioButton_downsample.isChecked() and self.lineEdit_Downsample_Ratio.text() == "":
            self.lineEdit_Downsample_Ratio.setText("1.0")
        if self.radioButton_slicing.isChecked() and self.lineEdit_Slicing_Percentage.text() == "":
            self.lineEdit_Slicing_Percentage.setText("0.9")
        if self.radioButton_jittering.isChecked() and self.lineEdit_Jittering_Ratio.text() == "":
            self.lineEdit_Jittering_Ratio.setText("0.1")

        if self.radioButton_upsample.isChecked(): upsample_ratio = float(self.lineEdit_Upsample_Ratio.text())
        if self.radioButton_downsample.isChecked(): downsample_ratio = float(self.lineEdit_Downsample_Ratio.text())
        if self.radioButton_slicing.isChecked(): slicing_pct = float(self.lineEdit_Slicing_Percentage.text())
        if self.radioButton_jittering.isChecked(): jitter_ratio = float(self.lineEdit_Jittering_Ratio.text())

        if self.radioButton_MDA.isChecked():
            if self.lineEdit_load_MDA.text() == "":
                QMessageBox.critical(self, "Error", "Please load your algorithm. ")
                return

        # Running box
        running_box = QMessageBox(self)
        running_box.setWindowTitle("Please wait")
        running_box.setText("BOLD signal augmenting! Please wait...")
        # running_box.setStandardButtons(QMessageBox.NoButton)
        running_box.show()
        QCoreApplication.processEvents()

        buttonname_lst = [self.radioButton_upsample, self.radioButton_downsample, self.radioButton_slicing,
                          self.radioButton_jittering, self.radioButton_MDA]
        for buttonname in buttonname_lst:
            if buttonname.isChecked():
                if buttonname.text() == "Upsampling, with ratio:":
                    self.Upsample(data, save_dir, upsample_ratio)
                elif buttonname.text() == "Downsampling, with ratio:":
                    self.Downsample(data, save_dir, downsample_ratio)
                elif buttonname.text() == "Slicing, with percentage:":
                    self.Slicing(data, save_dir, slicing_pct)
                elif buttonname.text() == "Noise Jittering, with std:":
                    self.NoiseJitter(data, save_dir, jitter_ratio)
                elif buttonname.text() == "Self-Defined Algorithm:":
                    dill.settings['recurse'] = True
                    with open(self.lineEdit_load_MDA.text(), 'rb') as f:
                        alg_fun = dill.load(f)
                    results = alg_fun(data)
                    np.save(os.path.join(save_dir, 'save_custom_augmented_result.npy'), results)

        # Finished
        # running_box.reject()
        running_box.close()
        QMessageBox.information(self, "Successful", "BOLD signal augmentation complete! ")

    def Upsample(self, input_data, save_dir, upsample_ratio):
        time_point = input_data.shape[2]
        upsample_data = resample(input_data, num=int(time_point * 1.0 / upsample_ratio), axis=2)
        np.save(os.path.join(save_dir, 'save_data_upsample_ratio_' + str(upsample_ratio) + '.npy'), upsample_data)

    def Downsample(self, input_data, save_dir, downsample_ratio):
        time_point = input_data.shape[2]
        downsample_data = resample(input_data, num=int(time_point * downsample_ratio), axis=2)
        np.save(os.path.join(save_dir, 'save_data_downsample_ratio_' + str(downsample_ratio) + '.npy'), downsample_data)

    def Slicing(self, input_data, save_dir, slicing_pct):
        time_point = input_data.shape[2]
        starting_point = randrange(time_point - int(time_point * slicing_pct) + 1)
        sliced_data = input_data[:, :, starting_point:starting_point+int(time_point * slicing_pct)]
        np.save(os.path.join(save_dir, 'save_data_slicing_percent_' + str(slicing_pct) + '.npy'), sliced_data)

    def NoiseJitter(self, input_data, save_dir, jitter_ratio):
        noise = np.random.normal(0, jitter_ratio, input_data.shape)
        jittered_data = input_data + noise
        np.save(os.path.join(save_dir, 'save_data_jitter_ratio_' + str(jitter_ratio) + '.npy'), jittered_data)

    def Help(self):
        QMessageBox.about(self,
            "Help Info",
            "<p>  This module is for BOLD signal augmentation. </p>"
            "<p>- Input data should be of size (S, N, T). </p>"
            "<p>- Hyper-parameter of Upsampling, Downsampling, and Slicing should be between 0 and 1. </p>"
            "<p>- Hyper-parameter of Noise Jittering should be non-negative. </p>"
            "<p>  Symbol meaning: S is the number of subjects, N is the number of brain regions/nodes, T is the number of time points. </p>"
        )

    def CleaR(self):
        self.lineEdit_Browse_Data.clear()
        self.lineEdit_Upsample_Ratio.clear()
        self.lineEdit_Downsample_Ratio.clear()
        self.lineEdit_Slicing_Percentage.clear()
        self.lineEdit_Jittering_Ratio.clear()
        self.lineEdit_Browse_SaveDir.clear()
        self.lineEdit_Browse_SaveDir.clear()

