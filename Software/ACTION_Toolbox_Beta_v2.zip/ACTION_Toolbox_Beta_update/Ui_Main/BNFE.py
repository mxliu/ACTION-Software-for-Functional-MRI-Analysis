from PyQt5 import QtWidgets
from PyQt5.QtWidgets import *
from PyQt5.uic import loadUi
from PyQt5.QtCore import QCoreApplication
import numpy as np
import networkx as nx
import os

class Ui_NFE(QDialog):
    def __init__(self):
        super(Ui_NFE, self).__init__()

        loadUi('./ui2/NFE.ui', self)

        self.pushButton_Browse_Data.clicked.connect(self.BrowseData_load)
        self.pushButton_Browse_SaveDir.clicked.connect(self.BrowseSaveDir)
        self.pushButton_CreateFeatures.clicked.connect(self.CreatFeatures)
        self.pushButton_Help.clicked.connect(self.Help)
        self.Clear.clicked.connect(self.CleaR)


    def BrowseData_load(self):
        file_name = QFileDialog.getOpenFileName(self, 'Open File', 'materials',
                                                'matrix data, with shape (S, N, N) (*.npy)',
                                                options=QtWidgets.QFileDialog.DontUseNativeDialog)
        self.lineEdit_Browse_Data.setText(file_name[0])

    def BrowseSaveDir(self):
        folder_name = QFileDialog.getExistingDirectory(self, 'Select Directory',
                                                       options=QtWidgets.QFileDialog.DontUseNativeDialog)
        self.lineEdit_Browse_SaveDir.setText(folder_name)

    def Load_file(self, file_name):
        data = np.load(file_name)
        return data

    def CreatFeatures(self):
        file_name = self.lineEdit_Browse_Data.text()
        if not file_name:
            QMessageBox.critical(self, "Error", "Input is empty.")
            return
        data = self.Load_file(file_name)
        if data.ndim != 3:
            QMessageBox.critical(self, "Error", "Input shape error. Data must be a 3-dimensional matrix with shape (S, N, N), "
                                                "where S is the number of subjects and N is the number of nodes. "
                                                "Please check your input dimensions.")
            self.lineEdit_Browse_Data.clear()
            return
        if data.shape[1] != data.shape[2]:
            QMessageBox.critical(self, "Error", "Input shape error. Data must be a 3-dimensional matrix with shape (S, N, N), "
                                                "where S is the number of subjects and N is the number of nodes. "
                                                "Please check your input dimensions.")
            self.lineEdit_Browse_Data.clear()
            return

        if self.lineEdit_Browse_SaveDir.text() == "": save_dir = './results'
        else: save_dir = self.lineEdit_Browse_SaveDir.text()

        weight_n, weight_g = None, None
        if self.checkBox_weight_n.isChecked(): weight_n = 'weight'
        if self.checkBox_weight_g.isChecked(): weight_g = 'weight'

        feature_vector, node_based_fea, graph_based_fea = None, None, None
        selected_alg_idx = []

        # Running box
        running_box = QMessageBox(self)
        running_box.setWindowTitle("Please wait")
        running_box.setText("Brain network feature extracting! Please wait...")
        # running_box.setStandardButtons(QMessageBox.NoButton)
        running_box.show()
        QCoreApplication.processEvents()

        node_based_type = [self.checkBox_deg, self.checkBox_str, self.checkBox_local_eff, self.checkBox_eig,
                            self.checkBox_clu, self.checkBox_bet]
        graph_based_type = [self.checkBox_den, self.checkBox_global_eff, self.checkBox_ass, self.checkBox_cha,
                            self.checkBox_tra,self.checkBox_mod]
        for type in node_based_type:
            if type.isChecked():
                if type.text() == "Node degree (Index:1)":
                    selected_alg_idx.append("1")
                    r = self.Node_degree(data)
                    if node_based_fea is None: node_based_fea = r
                    else: node_based_fea = np.concatenate((node_based_fea, r), axis=1)
                if type.text() == "Node strength (Index:2)":
                    selected_alg_idx.append("2")
                    r = self.Node_strength(data)
                    if node_based_fea is None: node_based_fea = r
                    else: node_based_fea = np.concatenate((node_based_fea, r), axis=1)
                if type.text() == "Local effciency (Index:3)":
                    selected_alg_idx.append("3")
                    r = self.Local_effciency(data)
                    if node_based_fea is None: node_based_fea = r
                    else: node_based_fea = np.concatenate((node_based_fea, r), axis=1)
                if type.text() == "Eigenvector centrality (Index:4)":
                    selected_alg_idx.append("4")
                    r = self.Eigenvector_centrality(data, weight=weight_n)
                    if node_based_fea is None: node_based_fea = r
                    else: node_based_fea = np.concatenate((node_based_fea, r), axis=1)

                if type.text() == "Clustering coefficient (Index:5)":
                    selected_alg_idx.append("5")
                    r = self.Clustering_coefficient(data, weight=weight_n)
                    if node_based_fea is None: node_based_fea = r
                    else: node_based_fea = np.concatenate((node_based_fea, r), axis=1)
                if type.text() == "Betweenness centrality (Index:6)":
                    selected_alg_idx.append("6")
                    r = self.Betweenness_centrality(data, weight=weight_n)
                    if node_based_fea is None: node_based_fea = r
                    else: node_based_fea = np.concatenate((node_based_fea, r), axis=1)
        if node_based_fea is not None: node_based_fea = np.nan_to_num(node_based_fea, nan=0)
        feature_vector = node_based_fea

        for type in graph_based_type:
            if type.isChecked():

                if type.text() == "Density (Index:7)":
                    selected_alg_idx.append("7")
                    r = self.Density(data)
                    if graph_based_fea is None: graph_based_fea = r
                    else: graph_based_fea = np.concatenate((graph_based_fea, r), axis=1)
                if type.text() == "Global efficiency (Index:8)":
                    selected_alg_idx.append("8")
                    r = self.Global_efficiency(data)
                    if graph_based_fea is None: graph_based_fea = r
                    else: graph_based_fea = np.concatenate((graph_based_fea, r), axis=1)
                if type.text() == "Assortativity coefficient (Index:9)":
                    selected_alg_idx.append("9")
                    r = self.Assortativity_coefficient(data, weight=weight_g)
                    if graph_based_fea is None: graph_based_fea = r
                    else: graph_based_fea = np.concatenate((graph_based_fea, r), axis=1)
                if type.text() == "Characteristic path length (Index:10)":
                    selected_alg_idx.append("10")
                    r = self.Characteristic_path_length(data, weight=weight_g)
                    if graph_based_fea is None: graph_based_fea = r
                    else: graph_based_fea = np.concatenate((graph_based_fea, r), axis=1)
                if type.text() == "Transitivity (Index:11)":
                    selected_alg_idx.append("11")
                    r = self.Transitivity(data)
                    if graph_based_fea is None: graph_based_fea = r
                    else: graph_based_fea = np.concatenate((graph_based_fea, r), axis=1)
                if type.text() == "Modularity (Index:12)":
                    selected_alg_idx.append("12")
                    r = self.Modularity(data, weight=weight_n)
                    if graph_based_fea is None: graph_based_fea = r
                    else: graph_based_fea = np.concatenate((graph_based_fea, r), axis=1)

        if graph_based_fea is not None: graph_based_fea = np.nan_to_num(graph_based_fea, nan=0)
        if feature_vector is None: feature_vector = graph_based_fea
        elif feature_vector is not None and graph_based_fea is None: feature_vector = node_based_fea
        else: feature_vector = np.concatenate((feature_vector, graph_based_fea), axis=1)

        if feature_vector is None:
            QMessageBox.critical(self, "Error", "Please select at least one option. ")
            # running_box.reject()
            running_box.close()
            return
        else:
            name = '_'.join(selected_alg_idx)
            np.save(os.path.join(save_dir, 'save_feature_' + name + '.npy'), feature_vector)
            # if node_based_fea is not None:
            #     np.save(os.path.join(save_dir, 'save_node_based_feature.npy'), node_based_fea)
            # if graph_based_fea is not None:
            #     np.save(os.path.join(save_dir, 'save_graph_based_feature.npy'), graph_based_fea)


        # Finished
        # running_box.reject()
        running_box.close()
        QMessageBox.information(self, "Successful", "Brain network feature extraction complete! ")


    def Node_degree(self, data):
        r = []
        for adj in data:
            graph = nx.from_numpy_array(adj)
            degree_vec = np.array(list(dict(graph.degree()).values()))
            r.append(degree_vec)
        # print('yes1')
        return np.stack(r, axis=0)

    def Node_strength(self, data):
        r = []
        for adj in data:
            graph = nx.from_numpy_array(adj)
            strength = np.array(list(dict(graph.degree(weight='weight')).values()))
            r.append(strength)
        # print('yes2')
        return np.stack(r, axis=0)

    def Local_effciency(self, data):
        r = []
        for adj in data:
            graph = nx.from_numpy_array(adj)
            l_eff = nx.local_efficiency(graph)
            r.append(l_eff)
        # print('yes3')
        return np.stack(r, axis=0).reshape(-1, 1)

    def Eigenvector_centrality(self, data, weight=None):
        r = []
        for adj in data:
            graph = nx.from_numpy_array(adj)
            eigenvector = np.array(list(nx.eigenvector_centrality(graph, weight=weight).values()))
            r.append(eigenvector)
        # print('yes4')
        return np.stack(r, axis=0)

    def Modularity(self, data, weight=None):
        r = []
        # s=0
        for adj in data:
            graph = nx.from_numpy_array(adj)
            communities = list(nx.community.label_propagation_communities(graph))
            modularity = nx.algorithms.community.modularity(graph, communities, weight=weight)
            r.append(modularity)
            # s += 1
            # print(s)
        return np.stack(r, axis=0).reshape(-1, 1)

    def Clustering_coefficient(self, data, weight=None):
        r = []
        for adj in data:
            graph = nx.from_numpy_array(adj)
            clustering = np.array(list(nx.clustering(graph, weight=weight).values()))
            r.append(clustering)
        # print('yes5')
        return np.stack(r, axis=0)

    def Betweenness_centrality(self, data, weight=None):
        r = []
        for adj in data:
            graph = nx.from_numpy_array(adj)
            betweenness = np.array(list(nx.betweenness_centrality(graph, weight=weight).values()))
            r.append(betweenness)
        # print('yes6')
        return np.stack(r, axis=0)

    def Density(self, data):
        r = []
        for adj in data:
            graph = nx.from_numpy_array(adj)
            density = nx.density(graph)
            r.append(density)
        # print('yes7')
        return np.stack(r, axis=0).reshape(-1, 1)

    def Global_efficiency(self, data):
        r = []
        for adj in data:
            graph = nx.from_numpy_array(adj)
            g_eff = nx.global_efficiency(graph)
            r.append(g_eff)
        # print('yes8')
        return np.stack(r, axis=0).reshape(-1, 1)

    def Assortativity_coefficient(self, data, weight=None):
        r = []
        for adj in data:
            graph = nx.from_numpy_array(adj)
            ass = nx.degree_assortativity_coefficient(graph, weight=weight)
            r.append(ass)
        # print('yes9')
        return np.stack(r, axis=0).reshape(-1, 1)

    def Characteristic_path_length(self, data, weight=None):
        r = []
        for adj in data:
            graph = nx.from_numpy_array(adj)
            path_length = nx.average_shortest_path_length(graph, weight=weight)
            r.append(path_length)
        # print('yes10')
        return np.stack(r, axis=0).reshape(-1, 1)

    def Transitivity(self, data):
        r = []
        for adj in data:
            graph = nx.from_numpy_array(adj)
            transitivity = nx.transitivity(graph)
            r.append(transitivity)
        # print('yes11')
        return np.stack(r, axis=0).reshape(-1, 1)

    def Help(self):
        QMessageBox.about(self,
            "Help Info",
            "<p>  This module is for brain network feature extraction, including node-based and graph-based features. </p>"
            "<p>- Input data should be of size (S, N, N). </p>"
            "<p>  Symbol meaning: S is the number of subjects, N is the number of nodes. </p>"
        )

    def CleaR(self):
        self.lineEdit_Browse_Data.clear()
        self.lineEdit_Browse_SaveDir.clear()
        self.checkBox_deg.setChecked(False)
        self.checkBox_str.setChecked(False)
        self.checkBox_local_eff.setChecked(False)
        self.checkBox_eig.setChecked(False)
        self.checkBox_mod.setChecked(False)
        self.checkBox_clu.setChecked(False)
        self.checkBox_bet.setChecked(False)
        self.checkBox_den.setChecked(False)
        self.checkBox_global_eff.setChecked(False)
        self.checkBox_ass.setChecked(False)
        self.checkBox_cha.setChecked(False)
        self.checkBox_tra.setChecked(False)
        self.checkBox_weight_n.setChecked(False)
        self.checkBox_weight_g.setChecked(False)

