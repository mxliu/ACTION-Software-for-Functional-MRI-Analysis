from PyQt5 import QtWidgets
from PyQt5.QtWidgets import *
from PyQt5.uic import loadUi
from PyQt5.QtGui import *
from PyQt5.QtCore import QCoreApplication
import numpy as np
from sklearn.decomposition import SparseCoder
from sklearn.metrics import mutual_info_score
from sklearn.preprocessing import KBinsDiscretizer
from scipy import stats, linalg
from scipy.stats import spearmanr
import matplotlib.pyplot as plt
import networkx as nx
import tempfile
import os
import dill
from Ui_Main import acc_grad
import warnings

class Ui_BNC_Vis(QDialog):
    def __init__(self):
        super(Ui_BNC_Vis, self).__init__()

        loadUi('./ui2/BNC_Vis.ui', self)

        self.results = None
        self.pushButton_MDA.setEnabled(False)

        self.loaddata_browse_bnc.clicked.connect(self.BrowseData_load)
        self.savepath_browse_bnc.clicked.connect(self.BrowseData_save)
        self.pushButton_MDA.clicked.connect(self.BrowseAlg_load)
        self.run_save.clicked.connect(self.Run_save)
        self.visualization.clicked.connect(self.Visualization)
        self.pushButton_Help.clicked.connect(self.Help)
        self.radioButton_BT.toggled.connect(self.update_BT_Text_State)
        self.radioButton_SR_2.toggled.connect(self.update_SR_2_Text_State)
        self.radioButton_SR.toggled.connect(self.update_SR_Text_State)
        self.radioButton_LR.toggled.connect(self.update_SR_Text_State2)
        self.radioButton_MDA.toggled.connect(self.enable_pushButton_MDA)
        self.lineEdit_Reg_p.textChanged.connect(self.checkInput_SP)
        self.lineEdit_Reg_p_2.textChanged.connect(self.checkInput_LRP)
        self.lineEdit_BT.textChanged.connect(self.checkInput_BT)
        self.lineEdit_SR.textChanged.connect(self.checkInput_SR)
        self.Clear.clicked.connect(self.CleaR)


    def BrowseData_load(self):
        file_name = QFileDialog.getOpenFileName(self, 'Open File', 'materials',
                                                'matrix data, with shape (S, N, T) (*.npy)',
                                                options=QtWidgets.QFileDialog.DontUseNativeDialog)
        self.loaddatatxt_bnc.setText(file_name[0])

    def BrowseData_save(self):
        save_path = QFileDialog.getExistingDirectory(self, 'Save File',
                                                     options=QtWidgets.QFileDialog.DontUseNativeDialog)
        self.savepathtxt_bnc.setText(save_path)

    def BrowseAlg_load(self):
        # Please ensure that all dependencies required by the function are properly encapsulated within the pkl file by 'dill' and correctly installed on the device.
        alg_name = QFileDialog.getOpenFileName(self, 'Open File', 'algorithm',
                                                'defined function, with input shape (S, N, T) and output shape (S, N, N) (*.pkl)',
                                                options=QtWidgets.QFileDialog.DontUseNativeDialog)
        self.lineEdit_load_MDA.setText(alg_name[0])

    def Load_file(self, file_name):
        data = np.load(file_name)
        return data

    def update_BT_Text_State(self, checked):
        if not checked:
            self.lineEdit_BT.setReadOnly(True)
            self.lineEdit_BT.setStyleSheet("color: gray")
        else:
            self.lineEdit_BT.setReadOnly(False)
            self.lineEdit_BT.setStyleSheet("color: black")

    def update_SR_2_Text_State(self, checked):
        if not checked:
            self.lineEdit_SR.setReadOnly(True)
            self.lineEdit_SR.setStyleSheet("color: gray")
        else:
            self.lineEdit_SR.setReadOnly(False)
            self.lineEdit_SR.setStyleSheet("color: black")

    def update_SR_Text_State(self, checked):
        if not checked:
            self.label_Reg_p.setStyleSheet("color: gray")
            self.lineEdit_Reg_p.setStyleSheet("color: gray")
            self.lineEdit_Reg_p.setReadOnly(True)
        else:
            self.label_Reg_p.setStyleSheet("color: black")
            self.lineEdit_Reg_p.setStyleSheet("color: black")
            self.lineEdit_Reg_p.setReadOnly(False)

    def update_SR_Text_State2(self, checked):
        if not checked:
            self.label_Reg_p_2.setStyleSheet("color: gray")
            self.lineEdit_Reg_p_2.setStyleSheet("color: gray")
            self.lineEdit_Reg_p_2.setReadOnly(True)
        else:
            self.label_Reg_p_2.setStyleSheet("color: black")
            self.lineEdit_Reg_p_2.setStyleSheet("color: black")
            self.lineEdit_Reg_p_2.setReadOnly(False)

    def checkInput_SP(self, text):
        if text.strip() == "":
            return
        try:
            value = float(text)
            if value <= 0:
                raise ValueError("Input value must be a non-negative number.")
        except ValueError as e:
            QMessageBox.critical(self, "Error", str(e))
            self.lineEdit_Reg_p.clear()

    def checkInput_LRP(self, text):
        if text.strip() == "":
            return
        try:
            value = float(text)
            if value <= 0:
                raise ValueError("Input value must be a non-negative number.")
        except ValueError as e:
            QMessageBox.critical(self, "Error", str(e))
            self.lineEdit_Reg_p_2.clear()

    def checkInput_BT(self, text):
        if text.strip() == "":
            return
        try:
            value = float(text)
            if value < 0 or value > 100:
                raise ValueError("Input value must be between 0 and 100.")
        except ValueError as e:
            QMessageBox.critical(self, "Error", str(e))
            self.lineEdit_BT.clear()

    def checkInput_SR(self, text):
        if text.strip() == "":
            return
        try:
            value = float(text)
            if value < 0 or value > 100:
                raise ValueError("Input value must be between 0 and 100.")
        except ValueError as e:
            QMessageBox.critical(self, "Error", str(e))
            self.lineEdit_SR.clear()

    def enable_pushButton_MDA(self, checked):
        if checked:
            self.pushButton_MDA.setEnabled(True)
        else:
            self.pushButton_MDA.setEnabled(False)

    def Run_save(self):
        file_name = self.loaddatatxt_bnc.text()
        if not file_name:
            QMessageBox.critical(self, "Error", "Input is empty.")
            return
        data = self.Load_file(file_name)
        if data.ndim != 3:
            QMessageBox.critical(self, "Error", "Input shape error. Data must be a 3-dimensional matrix with a shape of (S, N, T), "
                                                "where S is the number of subjects, N is the number of nodes, and T is the time points. "
                                                "Please check your input dimensions. ")
            self.loaddatatxt_bnc.clear()
            return

        if self.savepathtxt_bnc.text() == "": save_path = './results'
        else: save_path = self.savepathtxt_bnc.text()

        if self.radioButton_BT.isChecked() and self.lineEdit_BT.text() == "":
            self.lineEdit_BT.setText("30")
        if self.radioButton_SR_2.isChecked() and self.lineEdit_SR.text() == "":
            self.lineEdit_SR.setText("30")
        if self.radioButton_SR.isChecked() and self.lineEdit_Reg_p.text() == "":
            self.lineEdit_Reg_p.setText("1")
        if self.radioButton_LR.isChecked() and self.lineEdit_Reg_p_2.text() == "":
            self.lineEdit_Reg_p_2.setText("1")

        if self.radioButton_SR.isChecked():
            try:
                float(self.lineEdit_Reg_p.text())
            except ValueError:
                QMessageBox.critical(self, "Error", "Sparse parameter must be a number. ")
                self.lineEdit_Reg_p.clear()
                return

        if self.radioButton_LR.isChecked():
            try:
                float(self.lineEdit_Reg_p_2.text())
            except ValueError:
                QMessageBox.critical(self, "Error", "Low-rank parameter must be a number. ")
                self.lineEdit_Reg_p_2.clear()
                return

        if self.radioButton_None.isChecked(): Bi_threshold, Sp_Ratio = None, None
        if self.radioButton_BT.isChecked(): Bi_threshold, Sp_Ratio = float(self.lineEdit_BT.text()), None
        if self.radioButton_SR_2.isChecked(): Bi_threshold, Sp_Ratio = None, float(self.lineEdit_SR.text())
        if self.radioButton_SR.isChecked(): Reg_p = float(self.lineEdit_Reg_p.text())
        if self.radioButton_LR.isChecked(): Reg_p_2 = float(self.lineEdit_Reg_p_2.text())

        if self.radioButton_MDA.isChecked():
            if self.lineEdit_load_MDA.text() == "":
                QMessageBox.critical(self, "Error", "Please load your algorithm. ")
                return

        # Running box
        running_box = QMessageBox(self)
        running_box.setWindowTitle("Please wait")
        running_box.setText("Brain network constructing! Please wait...")
        # running_box.setStandardButtons(QMessageBox.NoButton)
        running_box.show()
        QCoreApplication.processEvents()

        warnings.filterwarnings('ignore', category=FutureWarning)
        Algorithm = [self.radioButton_PC, self.radioButton_HOFC, self.radioButton_SR, self.radioButton_MI,
                     self.radioButton_LR, self.radioButton_ParC, self.radioButton_SC, self.radioButton_MDA]
        for alg in Algorithm:
            if alg.isChecked():
                if alg.text() == "Pearson's Correlation (PC)":
                    self.results = self.PC(data, save_path, Bi_threshold, Sp_Ratio)
                elif alg.text() == "High-Order Functional Connectivity (HOFC)":
                    self.results = self.HOFC(data, save_path, Bi_threshold, Sp_Ratio)
                elif alg.text() == "Sparse Representation (SR)":
                    self.results = self.SR(data, Reg_p, save_path, Bi_threshold, Sp_Ratio)
                elif alg.text() == "Mutual Information (MI)":
                    self.results = self.MI(data, save_path, Bi_threshold, Sp_Ratio)
                elif alg.text() == "Low-rank Representation (LR)":
                    self.results = self.LR(data, Reg_p_2, save_path, Bi_threshold, Sp_Ratio)
                elif alg.text() == "Partial Correlation (PrC)":
                    self.results = self.P_C(data, save_path, Bi_threshold, Sp_Ratio)
                elif alg.text() == "Spearman's Correlation (SC)":
                    self.results = self.SC(data, save_path, Bi_threshold, Sp_Ratio)
                elif alg.text() == "Self-Defined Algorithm:":
                    dill.settings['recurse'] = True
                    with open(self.lineEdit_load_MDA.text(), 'rb') as f:
                        alg_fun = dill.load(f)
                    self.results = alg_fun(data)
                    if self.radioButton_BT.isChecked():
                        self.results = self.T_Binarization(self.results, Bi_threshold)
                        np.save(os.path.join(save_path, 'Custom_Adjacency_Matrix_Binarization_' + str(Bi_threshold) + '%.npy'), self.results)
                    elif self.radioButton_SR_2.isChecked():
                        self.results = self.K_Sparsity(self.results, Sp_Ratio)
                        np.save(os.path.join(save_path, 'Custom_Adjacency_Matrix_Sparsity_' + str(Sp_Ratio) + '%.npy'), self.results)
                    else:
                        np.save(os.path.join(save_path, 'Custom_Adjacency_Matrix.npy'), self.results)

        # Finished
        # running_box.reject()
        running_box.close()
        QMessageBox.information(self, "Successful", "Brain network construction complete! ")

    def Visualization(self):
        if self.results is None:
            QMessageBox.critical(self, "Error", "Please run first.")
            return
        subj_num = self.results.shape[0]
        if self.lineEdit_vis.text() == "":
            self.lineEdit_vis.setText("1")

        try:
            float(self.lineEdit_vis.text())
        except ValueError:
            QMessageBox.critical(self, "Error", "Input value must be an integer between 1 and " + str(subj_num) + ".")
            self.lineEdit_vis.clear()
            return

        subj_id = float(self.lineEdit_vis.text())
        if not subj_id.is_integer() or subj_id > subj_num or subj_id < 1:
            QMessageBox.critical(self, "Error", "Input value must be an integer between 1 and " + str(subj_num) + ".")
            self.lineEdit_vis.clear()
            return
        matrix = self.results[int(subj_id)-1]
        # adj_matrix
        plt.imshow(matrix, cmap='viridis', interpolation='nearest', extent=[0, 1, 0, 1], vmin=-1.0, vmax=1.0)
        plt.colorbar()
        plt.axis('off')
        temp_file = tempfile.NamedTemporaryFile(suffix=".png", delete=False)
        plt.savefig(temp_file.name)
        plt.close()
        pixmap = QPixmap(temp_file.name)
        self.label_adj_mat.setPixmap(pixmap)
        self.label_adj_mat.setScaledContents(True)
        temp_file.close()
        os.unlink(temp_file.name)
        # brain_net
        A = np.where(matrix != 0., 1., 0.)
        W = np.ones((A.shape[0], A.shape[1]))
        G = nx.Graph()
        G.add_nodes_from(range(len(A)))
        for i in range(len(A)):
            for j in range(i+1, len(A)):
                if A[i ,j] == 1:
                    G.add_edge(i, j, weight=W[i, j])
        _, ax = plt.subplots()
        pos = nx.spring_layout(G, seed=0)
        nx.draw_networkx(G, pos, with_labels=False, font_weight='bold', node_size=50,
                node_color='lightcoral', font_color='black', edge_color='gray', ax=ax)
        temp_file = tempfile.NamedTemporaryFile(suffix=".png", delete=False)
        plt.savefig(temp_file.name)
        plt.close()
        pixmap = QPixmap(temp_file.name)
        self.label_brain_net.setPixmap(pixmap)
        self.label_brain_net.setScaledContents(True)
        temp_file.close()
        os.unlink(temp_file.name)


    def K_Sparsity(self, matrix, m):
        num_subj = matrix.shape[0]
        num_node = matrix.shape[1]
        r = np.zeros((num_subj, num_node, num_node))
        for i in range(num_subj):
            x = matrix[i]
            threshold = np.percentile(x, 100 - m)
            r[i] = np.where(x < threshold, 0, x)
        return r

    def T_Binarization(self, matrix, m):
        num_subj = matrix.shape[0]
        num_node = matrix.shape[1]
        r = np.zeros((num_subj, num_node, num_node))
        for i in range(num_subj):
            x = matrix[i]
            threshold = np.percentile(x, 100 - m)
            x = np.where(x < threshold, 0., x)
            r[i] = np.where(x != 0., 1., 0.)
        return r

    def PC(self, data, save_path, Bi_threshold=None, Sp_Ratio=None):
        data = np.transpose(data, (0, 2, 1))
        Network = []
        for i in range(len(data)):
            signal = data[i].T
            network = np.corrcoef(signal)
            Network.append(network)
        PC_matrices = np.array(Network)
        if Sp_Ratio is not None:
            PC_matrices = self.K_Sparsity(PC_matrices, Sp_Ratio)
            np.save(os.path.join(save_path, 'PC_Adjacency_Matrix_Sparsity_' + str(Sp_Ratio) + '%.npy'), PC_matrices)
        if Bi_threshold is not None:
            PC_matrices = self.T_Binarization(PC_matrices, Bi_threshold)
            np.save(os.path.join(save_path, 'PC_Adjacency_Matrix_Binarization_' + str(Bi_threshold) + '%.npy'), PC_matrices)
        else: np.save(os.path.join(save_path, 'PC_Adjacency_Matrix.npy'), PC_matrices)
        return PC_matrices

    def HOFC(self, data, save_path, Bi_threshold=None, Sp_Ratio=None):
        data = np.transpose(data, (0, 2, 1))
        Network = []
        for i in range(len(data)):
            signal = data[i].T
            network = np.corrcoef(np.corrcoef(signal))
            Network.append(network)
        HOFC_matrices = np.array(Network)
        if Sp_Ratio is not None:
            HOFC_matrices = self.K_Sparsity(HOFC_matrices, Sp_Ratio)
            np.save(os.path.join(save_path, 'HOFC_Adjacency_Matrix_Sparsity_' + str(Sp_Ratio) + '%.npy'), HOFC_matrices)
        if Bi_threshold is not None:
            HOFC_matrices = self.T_Binarization(HOFC_matrices, Bi_threshold)
            np.save(os.path.join(save_path, 'HOFC_Adjacency_Matrix_Binarization_' + str(Bi_threshold) + '%.npy'),
                    HOFC_matrices)
        else:
            np.save(os.path.join(save_path, 'HOFC_Adjacency_Matrix.npy'), HOFC_matrices)
        return HOFC_matrices

    def SR(self, data, lam, save_path, Bi_threshold=None, Sp_Ratio=None):
        data = np.transpose(data, (0, 2, 1))
        Network = []
        for i in range(len(data)):
            signal = data[i].T
            sparse_coder = SparseCoder(dictionary=signal, transform_algorithm='lasso_lars', transform_alpha=lam)
            network = sparse_coder.transform(signal)
            network = (network + network.T) / 2
            Network.append(network)
        SR_matrices = np.array(Network)
        if Sp_Ratio is not None:
            SR_matrices = self.K_Sparsity(SR_matrices, Sp_Ratio)
            np.save(os.path.join(save_path, 'SR_Adjacency_Matrix_sparse_' + str(lam) + '_Sparsity_' + str(Sp_Ratio) + '%.npy'), SR_matrices)
        if Bi_threshold is not None:
            SR_matrices = self.T_Binarization(SR_matrices, Bi_threshold)
            np.save(os.path.join(save_path, 'SR_Adjacency_Matrix_sparse_' + str(lam) + '_Binarization_' + str(Bi_threshold) + '%.npy'), SR_matrices)
        else: np.save(os.path.join(save_path, 'SR_Adjacency_Matrix_sparse_' + str(lam) + '.npy'), SR_matrices)
        return SR_matrices

    def is_continuous(self, data):
        return np.issubdtype(data.dtype, np.floating)

    def discretize_data(self, data, n_bins=10):
        discretizer = KBinsDiscretizer(n_bins=n_bins, encode='ordinal', strategy='uniform')
        return discretizer.fit_transform(data.T).T

    def MI(self, data, save_path, Bi_threshold=None, Sp_Ratio=None, n_bins=10):
        S, N, T = data.shape
        MI_matrices = np.zeros((S, N, N))
        for s in range(S):
            sample = data[s]
            if self.is_continuous(sample):
                sample = self.discretize_data(sample, n_bins)
            for i in range(N):
                for j in range(i, N):
                    mi = mutual_info_score(sample[i], sample[j])
                    mi = np.clip(mi, -1.0, 1.0)
                    MI_matrices[s, i, j] = mi
                    MI_matrices[s, j, i] = mi
        if Sp_Ratio is not None:
            MI_matrices = self.K_Sparsity(MI_matrices, Sp_Ratio)
            np.save(os.path.join(save_path, 'MI_Adjacency_Matrix_Sparsity_' + str(Sp_Ratio) + '%.npy'), MI_matrices)
        if Bi_threshold is not None:
            MI_matrices = self.T_Binarization(MI_matrices, Bi_threshold)
            np.save(os.path.join(save_path, 'MI_Adjacency_Matrix_Binarization_' + str(Bi_threshold) + '%.npy'), MI_matrices)
        else: np.save(os.path.join(save_path, 'MI_Adjacency_Matrix.npy'), MI_matrices)
        return MI_matrices

    # def mutual_information_matrix(self, data):
    #     num_features = data.shape[1]
    #     mi_matrix = np.zeros((num_features, num_features))
    #     for i in range(num_features):
    #         for j in range(num_features):
    #             mi_matrix[i, j] = mutual_info_score(data[:, i], data[:, j])
    #     return mi_matrix
    #
    # def MI(self, data, save_path, Bi_threshold=None, Sp_Ratio=None):
    #     data = np.transpose(data, (0, 2, 1))
    #     Network = []
    #     for i in range(len(data)):
    #         signal = data[i]
    #         network = self.mutual_information_matrix(signal)
    #         Network.append(network)
    #     MI_matrices = np.array(Network)
    #     if Sp_Ratio is not None:
    #         MI_matrices = self.K_Sparsity(MI_matrices, Sp_Ratio)
    #         np.save(os.path.join(save_path, 'MI_Adjacency_Matrix_Sparsity_' + str(Sp_Ratio) + '%.npy'), MI_matrices)
    #     if Bi_threshold is not None:
    #         MI_matrices = self.T_Binarization(MI_matrices, Bi_threshold)
    #         np.save(os.path.join(save_path, 'MI_Adjacency_Matrix_Binarization_' + str(Bi_threshold) + '%.npy'), MI_matrices)
    #     else: np.save(os.path.join(save_path, 'MI_Adjacency_Matrix.npy'), MI_matrices)
    #     return MI_matrices

    def LR(self, data, lam, save_path, Bi_threshold=None, Sp_Ratio=None):
        data = np.transpose(data, (0, 2, 1))
        Network = []
        for i in range(len(data)):
            signal = data[i]
            q = np.shape(signal)[1]
            r = np.shape(signal)[1]
            initial = np.random.rand(q, r)
            network, _ = acc_grad.accelerated_gradient_tracenorm(signal, signal, lam, 1000, initial)
            Network.append(network)
        LR_matrices = np.real(np.array(Network))
        if Sp_Ratio is not None:
            LR_matrices = self.K_Sparsity(LR_matrices, Sp_Ratio)
            np.save(os.path.join(save_path, 'LR_Adjacency_Matrix_low_rank_' + str(lam) + '_Sparsity_' + str(Sp_Ratio) + '%.npy'), LR_matrices)
        if Bi_threshold is not None:
            LR_matrices = self.T_Binarization(LR_matrices, Bi_threshold)
            np.save(os.path.join(save_path, 'LR_Adjacency_Matrix_low_rank_' + str(lam) + '_Binarization_' + str(Bi_threshold) + '%.npy'), LR_matrices)
        else: np.save(os.path.join(save_path, 'LR_Adjacency_Matrix_low_rank_' + str(lam) + '.npy'), LR_matrices)
        return LR_matrices

    def partial_corr(self, C):
        C = np.asarray(C)
        p = C.shape[1]
        P_corr = np.zeros((p, p), dtype=float)
        for i in range(p):
            P_corr[i, i] = 1
            for j in range(i + 1, p):
                idx = np.ones(p, dtype=bool)
                idx[i] = False
                idx[j] = False
                beta_i = linalg.lstsq(C[:, idx], C[:, j])[0]
                beta_j = linalg.lstsq(C[:, idx], C[:, i])[0]
                res_j = C[:, j] - C[:, idx].dot(beta_i)
                res_i = C[:, i] - C[:, idx].dot(beta_j)
                corr = stats.pearsonr(res_i, res_j)[0]
                P_corr[i, j] = corr
                P_corr[j, i] = corr
        return P_corr

    def P_C(self, data, save_path, Bi_threshold=None, Sp_Ratio=None):
        data = np.transpose(data, (0, 2, 1))
        Network = []
        for i in range(len(data)):
            signal = data[i]
            network = self.partial_corr(signal)
            Network.append(network)
        partial_corr_matrix = np.array(Network)
        if Sp_Ratio is not None:
            partial_corr_matrix = self.K_Sparsity(partial_corr_matrix, Sp_Ratio)
            np.save(os.path.join(save_path, 'Partial_Adjacency_Matrix_Sparsity_' + str(Sp_Ratio) + '%.npy'), partial_corr_matrix)
        if Bi_threshold is not None:
            partial_corr_matrix = self.T_Binarization(partial_corr_matrix, Bi_threshold)
            np.save(os.path.join(save_path, 'Partial_Adjacency_Matrix_Binarization_' + str(Bi_threshold) + '%.npy'), partial_corr_matrix)
        else: np.save(os.path.join(save_path, 'Partial_Adjacency_Matrix.npy'), partial_corr_matrix)
        return partial_corr_matrix

    def SC(self, data, save_path, Bi_threshold=None, Sp_Ratio=None):
        data = np.transpose(data, (0, 2, 1))
        nodeNum = data.shape[2]
        Network = []
        for i in range(len(data)):
            signal = data[i]
            spearman_corr_matrix = np.zeros((nodeNum, nodeNum))
            for i in range(nodeNum):
                for j in range(i, nodeNum):  # Using j=i to avoid redundant calculations (symmetric matrix)
                    correlation, _ = spearmanr(signal[:, i], signal[:, j])
                    spearman_corr_matrix[i, j] = correlation
                    spearman_corr_matrix[j, i] = correlation
            network = spearman_corr_matrix  # np.corrcoef(loaded_object[i].T)  # (116,116)
            Network.append(network)
        sc_corr = np.array(Network)
        if Sp_Ratio is not None:
            sc_corr = self.K_Sparsity(sc_corr, Sp_Ratio)
            np.save(os.path.join(save_path, 'SC_Adjacency_Matrix_Sparsity_' + str(Sp_Ratio) + '%.npy'), sc_corr)
        if Bi_threshold is not None:
            sc_corr = self.T_Binarization(sc_corr, Bi_threshold)
            np.save(os.path.join(save_path, 'SC_Adjacency_Matrix_Binarization_' + str(Bi_threshold) + '%.npy'), sc_corr)
        else: np.save(os.path.join(save_path, 'SC_Adjacency_Matrix.npy'), sc_corr)
        return sc_corr


    def Help(self):
        QMessageBox.about(self,
            "Help Info",
            "<p>  This module is for brain network construction and network visualization. </p>"
            "<p>- Input data should be of size (S, N, T). </p>"
            "<p>- Sparse parameter and low-rank parameter should be non-negative. </p>"
            "<p>- Binarization threshold and sparsity ratio should be between 0 and 100. </p>"
            "<p>  Symbol meaning: S is the number of subjects, N is the number of brain regions/nodes, T is the number of time points. </p>"
        )

    def CleaR(self):
        self.loaddatatxt_bnc.clear()
        self.lineEdit_BT.clear()
        self.lineEdit_SR.clear()
        self.savepathtxt_bnc.clear()
        self.lineEdit_vis.clear()
        self.label_adj_mat.clear()
        self.label_brain_net.clear()
        self.lineEdit_Reg_p.clear()
        self.lineEdit_Reg_p_2.clear()
        self.lineEdit_load_MDA.clear()

