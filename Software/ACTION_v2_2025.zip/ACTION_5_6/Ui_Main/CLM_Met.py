from PyQt5 import QtWidgets
from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt, QCoreApplication
from PyQt5.uic import loadUi
from PyQt5.QtGui import QPixmap
import numpy as np
import random
from sklearn.model_selection import KFold
from sklearn.decomposition import PCA
from sklearn.feature_selection import SelectKBest, f_classif
from sklearn.metrics import mean_absolute_error, mean_squared_error, accuracy_score, roc_auc_score, recall_score, \
    confusion_matrix, precision_score, f1_score, balanced_accuracy_score, roc_curve, ConfusionMatrixDisplay
from sklearn.svm import SVR, SVC
from sklearn.ensemble import RandomForestRegressor, RandomForestClassifier
import xgboost as xgb
from sklearn.neighbors import KNeighborsRegressor, KNeighborsClassifier
import os
import json
import dill
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
import matplotlib.pyplot as plt
from scipy.stats import ttest_ind

class Ui_CLM_Met(QDialog):
    def __init__(self):
        super(Ui_CLM_Met, self).__init__()

        loadUi('./ui2/CLM_Met.ui', self)
        self.label_Figure.setScaledContents(True)
        self.Figure = QPixmap('./Image/fig_ConventionalML.jpg')
        self.label_Figure.setPixmap(self.Figure)

        self.pushButton_MDA.setEnabled(False)

        self.ground_truth, self.cls_Prob, self.cls_Pred = None, None, None

        self.pushButton_Browse_Data.clicked.connect(self.BrowseData)
        self.pushButton_Browse_Label.clicked.connect(self.BrowseLabel)
        self.pushButton_Browse_SaveDir.clicked.connect(self.BrowseSaveDir)
        self.radioButton_None.toggled.connect(self.Change_Rd_State)
        self.radioButton_reg.toggled.connect(self.ChangeTxt)
        self.radioButton_CV.toggled.connect(self.Update_CV_Text_State)
        self.radioButton_split.toggled.connect(self.Update_Train_Test_Text_State)
        self.radioButton_MDA.toggled.connect(self.enable_pushButton_MDA)
        self.lineEdit_train.textChanged.connect(self.Update_Test_Ratio)
        self.pushButton_MDA.clicked.connect(self.BrowseAlg_load)
        self.pushButton_Run.clicked.connect(self.Run)
        self.pushButton_Help.clicked.connect(self.Help)
        self.Clear.clicked.connect(self.CleaR)
        self.pushButton_ROC.clicked.connect(self.Vis_ROC)
        self.pushButton_CM.clicked.connect(self.Vis_CM)


    def BrowseData(self):
        file_name = QFileDialog.getOpenFileName(self, 'Open File', 'features',
                                                'matrix data, with shape (S, F) (*.npy)',
                                                options=QtWidgets.QFileDialog.DontUseNativeDialog)
        self.lineEdit_Browse_Data.setText(file_name[0])

    def BrowseLabel(self):
        file_name = QFileDialog.getOpenFileName(self, 'Open File', 'labels',
                                                'vector data, with shape (S, ) (*.npy)',
                                                options=QtWidgets.QFileDialog.DontUseNativeDialog)
        self.lineEdit_Browse_Label.setText(file_name[0])

    def BrowseSaveDir(self):
        folder_name = QFileDialog.getExistingDirectory(self, 'Select Directory',
                                                       options=QtWidgets.QFileDialog.DontUseNativeDialog)
        self.lineEdit_Browse_SaveDir.setText(folder_name)

    def BrowseAlg_load(self):
        # Please ensure that all dependencies required by the function are properly encapsulated within the pkl file by 'dill' and correctly installed on the device.
        alg_name = QFileDialog.getOpenFileName(self, 'Open File', 'algorithm',
                                                'defined function, with the correct input and output shape (*.pkl)',
                                                options=QtWidgets.QFileDialog.DontUseNativeDialog)
        self.lineEdit_load_MDA.setText(alg_name[0])

    def Change_Rd_State(self, checked):
        if not checked:
            self.lineEdit_dim.setReadOnly(False)
            self.lineEdit_dim.setStyleSheet("color: black")
        else:
            self.lineEdit_dim.setReadOnly(True)
            self.lineEdit_dim.setStyleSheet("color: gray")

    def ChangeTxt(self, checked):
        if not checked:
            self.radioButton_SVM.setText("Support Vector Machine (SVM)")
            self.label_select_cla.setText("Classifier:")
            self.pushButton_CM.setEnabled(True)
            self.pushButton_ROC.setEnabled(True)
        else:
            self.radioButton_SVM.setText("Support Vector Regression (SVR)")
            self.label_select_cla.setText("Regressor:")
            self.pushButton_CM.setEnabled(False)
            self.pushButton_ROC.setEnabled(False)

    def Update_CV_Text_State(self, checked):
        if not checked:
            self.lineEdit_CV.setReadOnly(True)
            self.lineEdit_CV.setStyleSheet("color: gray")
        else:
            self.lineEdit_CV.setReadOnly(False)
            self.lineEdit_CV.setStyleSheet("color: black")

    def Update_Train_Test_Text_State(self, checked):
        if not checked:
            self.lineEdit_train.setReadOnly(True)
            self.lineEdit_train.setStyleSheet("color: gray")
            self.lineEdit_test.setStyleSheet("color: gray")
        else:
            self.lineEdit_train.setReadOnly(False)
            self.lineEdit_train.setStyleSheet("color: black")
            self.lineEdit_test.setStyleSheet("color: black")

    def Update_Test_Ratio(self):
        if self.lineEdit_train.text() != "":
            try: float(self.lineEdit_train.text())
            except ValueError:
                QMessageBox.critical(self, "Error", "Training set ratio must be a number between 0 and 100.")
                self.lineEdit_train.clear()
                self.lineEdit_test.clear()
                return
        if self.lineEdit_train.text() == "":
            self.lineEdit_test.clear()
        elif float(self.lineEdit_train.text()) <= 0 or float(self.lineEdit_train.text()) >= 100:
            QMessageBox.critical(self, "Error", "Training set ratio must be between 0 and 100.")
            self.lineEdit_train.clear()
            self.lineEdit_test.clear()
        else:
            training_set_ratio = float(self.lineEdit_train.text())
            self.lineEdit_test.setText(str(100-training_set_ratio))

    def enable_pushButton_MDA(self, checked):
        if checked:
            self.pushButton_MDA.setEnabled(True)
        else:
            self.pushButton_MDA.setEnabled(False)

    def Load_file(self, file_name):
        data = np.load(file_name)
        return data

    def Run(self):
        Data_file_name = self.lineEdit_Browse_Data.text()
        Label_file_name = self.lineEdit_Browse_Label.text()
        if not Data_file_name or not Label_file_name:
            QMessageBox.critical(self, "Error", "Input incomplete.")
            return
        data = self.Load_file(Data_file_name)
        label = self.Load_file(Label_file_name)
        label_t = self.Load_file(Label_file_name)
        if data.ndim != 2 or label.ndim != 1 or data.shape[0] != label.shape[0]:
            QMessageBox.critical(self, "Error", "Input shape error. "
                                                "Data must be a 2-dimensional matrix with a shape of (S, F), "
                                                "and Label must be a 1-dimensional vector with a length of S, "
                                                "where S is the number of subjects and F is the dimension of features. "
                                                "Please check your input dimensions.")
            if data.ndim != 2: self.lineEdit_Browse_Data.clear()
            if label.ndim != 1: self.lineEdit_Browse_Label.clear()
            if data.shape[0] != label.shape[0]: self.lineEdit_Browse_Label.clear()
            return
        if self.radioButton_cls.isChecked():
            if not np.all((label == 0) | (label == 1)) and not np.all((label == -1) | (label == 1)):
                QMessageBox.critical(self, "Error", "Label for classification must consist of only 0 and 1 or only -1 and 1.")
                return

        if np.all((label == -1) | (label == 1)):
            label[label == -1] = 0
            self.ne = True
        else: self.ne = False

        if self.lineEdit_Browse_SaveDir.text() == "": save_dir = './results'
        else: save_dir = self.lineEdit_Browse_SaveDir.text()

        if self.radioButton_MDA.isChecked():
            if self.lineEdit_load_MDA.text() == "":
                QMessageBox.critical(self, "Error", "Please load your algorithm. ")
                return

        if self.lineEdit_dim.text() == "":
            self.lineEdit_dim.setText("1")

        if self.radioButton_CV.isChecked():
            if self.lineEdit_CV.text() == "":
                self.lineEdit_CV.setText("5")

        if self.radioButton_split.isChecked():
            if self.lineEdit_train.text() == "":
                self.lineEdit_train.setText("70")
                self.lineEdit_test.setText("30")

        try:
            float(self.lineEdit_dim.text())
        except ValueError:
            QMessageBox.critical(self, "Error",
                                 "Reduced dimension must be a number. ")
            self.lineEdit_dim.clear()
            return

        if self.radioButton_CV.isChecked():
            try:
                float(self.lineEdit_CV.text())
            except ValueError:
                QMessageBox.critical(self, "Error", "Fold number must be an integer of at least 2.")
                self.lineEdit_CV.clear()
                return
            if data.shape[0] < float(self.lineEdit_CV.text()):
                QMessageBox.critical(self, "Error", "Insufficient sample size.")
                self.lineEdit_CV.clear()
                return
            if float(self.lineEdit_CV.text()) < 2 or not float(self.lineEdit_CV.text()).is_integer():
                QMessageBox.critical(self, "Error", "Fold number must be an integer of at least 2.")
                self.lineEdit_CV.clear()
                return

        dim = float(self.lineEdit_dim.text())
        if self.radioButton_CV.isChecked(): CVNum = int(self.lineEdit_CV.text())

        # if self.radioButton_ICA.isChecked() or self.radioButton_CCA.isChecked():
        #     if not dim.is_integer() or dim < 1 or dim > min(data.shape[0], data.shape[1]):
        #         QMessageBox.critical(self, "Error",
        #                              "Reduced dimension must be an integer between 1 and " + str(
        #                                  min(data.shape[0], data.shape[1])) + ".")
        #         self.lineEdit_dim.clear()
        #         return

        if self.radioButton_ttest.isChecked() or self.radioButton_UFS.isChecked():
            if not dim.is_integer() or dim < 1 or dim > data.shape[1]:
                QMessageBox.critical(self, "Error",
                                     "Reduced dimension must be an integer between 1 and " + str(data.shape[1]) + ".")
                self.lineEdit_dim.clear()
                return

        elif self.radioButton_PCA.isChecked():
            if dim >= 1 and not dim.is_integer():
                QMessageBox.critical(self, "Error",
                                     "Reduced dimension must be a number between 0 and 1 or an integer between 1 and " + str(min(data.shape[0], data.shape[1])) + ". "
                                     "When 'Reduced dimension' is less than 1, it represents the lowest cumulative contribution rate of principal component variance satisfied; "
                                     "when 'Reduced dimension' is between 1 and " + str(min(data.shape[0], data.shape[1])) + ", "
                                     "it represents the number of maximum principal components selected.")
                self.lineEdit_dim.clear()
                return
            if dim <= 0 or dim > min(data.shape[0], data.shape[1]):
                QMessageBox.critical(self, "Error",
                                     "Reduced dimension must be a number between 0 and 1 or an integer between 1 and " + str(min(data.shape[0], data.shape[1])) + ". "
                                     "When 'Reduced dimension' is less than 1, it represents the lowest cumulative contribution rate of principal component variance satisfied; "
                                     "when 'Reduced dimension' is between 1 and " + str(min(data.shape[0], data.shape[1])) + ", "
                                     "it represents the number of maximum principal components selected.")
                self.lineEdit_dim.clear()
                return

        # Running box
        if not self.radioButton_None.isChecked():
            running_box = QMessageBox(self)
            running_box.setWindowTitle("Please wait")
            running_box.setText("Feature dimension reducing! Please wait...")
            # running_box.setStandardButtons(QMessageBox.NoButton)
            running_box.show()
            QCoreApplication.processEvents()

        # Extractor
        Ectractor_list = [self.radioButton_PCA, self.radioButton_UFS, self.radioButton_ttest, self.radioButton_None]
        for Ectractor in Ectractor_list:
            if Ectractor.isChecked():
                if Ectractor.text() == "Principal Component Analysis (PCA)":
                    e_name = "PCA"
                    fea_reduced = self.PCA(data, save_dir, dim)
                elif Ectractor.text() == "Univariate Feature Selection (UFS)":
                    e_name = "UFS"
                    fea_reduced = self.UFS(data, label, save_dir, dim)
                elif Ectractor.text() == "T-test":
                    e_name = "Ttest"
                    fea_reduced = self.Ttest(data, label, save_dir, dim)
                elif Ectractor.text() == "None":
                    e_name = "Original_feature"
                    fea_reduced = data

        # Change box text
        if not self.radioButton_None.isChecked():
            running_box.setText("Model executing! Please wait...")
            QCoreApplication.processEvents()
        else:
            running_box = QMessageBox(self)
            running_box.setWindowTitle("Please wait")
            running_box.setText("Model executing! Please wait...")
            # running_box.setStandardButtons(QMessageBox.NoButton)
            running_box.show()
            QCoreApplication.processEvents()

        # Split
        SplitMode_list = [self.radioButton_CV, self.radioButton_split]
        for mode in SplitMode_list:
            if mode.isChecked():
                if mode.text() == "":
                    split_result = self.DataSplit_CV(fea_reduced, label, CVNum)
                    if self.radioButton_cls.isChecked():
                        for s in split_result:
                            Label_test, Label_train = s['Label_test'], s['Label_train']
                            if np.all(Label_train == 0) or np.all(Label_train == 1) or np.all(Label_test == 0) or np.all(Label_test == 1):
                                QMessageBox.critical(self, "Error", "Training and validation samples must have 2 classes.")
                                return
                elif mode.text() == ".":
                    split_result = self.DataSplit_ratio(fea_reduced, label, float(self.lineEdit_train.text())/100.)
                    if self.radioButton_cls.isChecked():
                        Label_test, Label_train = split_result['Label_test'], split_result['Label_train']
                        if np.all(Label_train == 0) or np.all(Label_train == 1) or np.all(Label_test == 0) or np.all(Label_test == 1):
                            QMessageBox.critical(self, "Error", "Training and validation samples must have 2 classes.")
                            return

        # # Running box
        # running_box = QMessageBox(self)
        # running_box.setWindowTitle("Running")
        # running_box.setText("Model executing! Please wait...")
        # running_box.setStandardButtons(QMessageBox.NoButton)
        # running_box.show()
        # QCoreApplication.processEvents()

        # Classifier
        Classifier_list = [self.radioButton_SVM, self.radioButton_RF, self.radioButton_XGB, self.radioButton_KNN,
                           self.radioButton_MDA]
        if self.radioButton_cls.isChecked():
            for Classifier in Classifier_list:
                if Classifier.isChecked():
                    if Classifier.text() == "Support Vector Machine (SVM)":
                        if self.radioButton_CV.isChecked():
                            cls_Result = []
                            cls_Prob = []
                            cls_Pred = []
                            ground_truth = []
                            for f, split in enumerate(split_result):
                                train_idx, test_idx, Label_test, Label_train, Data_test, Data_train = \
                                    split['train_idx'], split['test_idx'], split['Label_test'], split['Label_train'], \
                                    split['Data_test'], split['Data_train']
                                Pred, Prob, Metric = self.SVMClssification(Label_test, Label_train, Data_test, Data_train)
                                if np.all((label_t == -1) | (label_t == 1)):
                                    Pred[Pred == 0] = -1
                                    Label_test[Label_test == 0] = -1
                                cls_Prob.append(Prob)
                                cls_Pred.append(Pred)
                                ground_truth.append(Label_test)
                                cls_Result.append({'fold':f, 'train_idx':train_idx.tolist(),
                                                   'test_idx':test_idx.tolist(), 'pred':Pred.tolist(),
                                                   'AUC':Metric[0], 'ACC':Metric[1], 'SEN':Metric[2],
                                                   'SPE':Metric[3], 'PRE':Metric[4], 'F1':Metric[5], 'BAC':Metric[6]})
                            self.cls_Prob = np.concatenate(cls_Prob, axis=0)
                            self.cls_Pred = np.concatenate(cls_Pred, axis=0)
                            self.ground_truth = np.concatenate(ground_truth, axis=0)
                            fina_result = self.Calculate_final_result_cls(cls_Result)
                            cls_Result.append({'final_result':'[mean, std]', 'AUC':fina_result['Area under the ROC curve'], 'ACC':fina_result['Accuracy'],
                                               'SEN':fina_result['Sensitive'], 'SPE':fina_result['Specificity'], 'PRE':fina_result['Precision'],
                                               'F1':fina_result['F1-score'], 'BAC':fina_result['Balanced accuracy']})
                            name = os.path.join(save_dir,
                                                'save_SVM_cls_result_' + e_name + '_CV_' + str(int(CVNum)) + '.json')
                            self.Savejosn(cls_Result, name)
                            self.Result_Tabel(fina_result)
                        if self.radioButton_split.isChecked():
                            train_idx, test_idx, Label_test, Label_train, Data_test, Data_train = \
                                split_result['train_idx'], split_result['test_idx'], split_result['Label_test'], \
                                split_result['Label_train'], split_result['Data_test'], split_result['Data_train']
                            Pred, Prob, Metric = self.SVMClssification(Label_test, Label_train, Data_test, Data_train)
                            if np.all((label_t == -1) | (label_t == 1)):
                                Pred[Pred == 0] = -1
                                Label_test[Label_test == 0] = -1
                            self.ground_truth, self.cls_Prob, self.cls_Pred = Label_test, Prob, Pred
                            cls_Result = {'train_idx':train_idx, 'test_idx':test_idx,
                                          'pred':Pred.tolist(), 'AUC':Metric[0], 'ACC':Metric[1], 'SEN':Metric[2],
                                          'SPE':Metric[3], 'PRE':Metric[4], 'F1':Metric[5], 'BAC':Metric[6]}
                            fina_result = {'Area under the ROC curve':Metric[0], 'Accuracy':Metric[1], 'Sensitive':Metric[2], 'Specificity':Metric[3],
                                           'Precision':Metric[4], 'F1-score':Metric[5], 'Balanced accuracy':Metric[6]}
                            name = os.path.join(save_dir,
                                                'save_SVM_cls_result_' + e_name + '_training_ratio_' + str(float(self.lineEdit_train.text())/100.) + '.json')
                            self.Savejosn(cls_Result, name)
                            self.Result_Tabel_2(fina_result)

                    elif Classifier.text() == "Random Forest (RF)":
                        if self.radioButton_CV.isChecked():
                            cls_Result = []
                            cls_Prob = []
                            cls_Pred = []
                            ground_truth = []
                            for f, split in enumerate(split_result):
                                train_idx, test_idx, Label_test, Label_train, Data_test, Data_train = \
                                    split['train_idx'], split['test_idx'], split['Label_test'], split['Label_train'], \
                                    split['Data_test'], split['Data_train']
                                Pred, Prob, Metric = self.RandomClssification(Label_test, Label_train, Data_test, Data_train)
                                if np.all((label_t == -1) | (label_t == 1)):
                                    Pred[Pred == 0] = -1
                                    Label_test[Label_test == 0] = -1
                                cls_Prob.append(Prob)
                                cls_Pred.append(Pred)
                                ground_truth.append(Label_test)
                                cls_Result.append({'fold': f, 'train_idx': train_idx.tolist(),
                                                   'test_idx': test_idx.tolist(), 'pred': Pred.tolist(),
                                                   'AUC': Metric[0], 'ACC': Metric[1], 'SEN': Metric[2],
                                                   'SPE': Metric[3], 'PRE': Metric[4], 'F1': Metric[5],
                                                   'BAC': Metric[6]})
                            self.cls_Prob = np.concatenate(cls_Prob, axis=0)
                            self.cls_Pred = np.concatenate(cls_Pred, axis=0)
                            self.ground_truth = np.concatenate(ground_truth, axis=0)
                            fina_result = self.Calculate_final_result_cls(cls_Result)
                            cls_Result.append(
                                {'final_result': '[mean, std]', 'AUC': fina_result['Area under the ROC curve'],
                                 'ACC': fina_result['Accuracy'],
                                 'SEN': fina_result['Sensitive'], 'SPE': fina_result['Specificity'],
                                 'PRE': fina_result['Precision'],
                                 'F1': fina_result['F1-score'], 'BAC': fina_result['Balanced accuracy']})
                            name = os.path.join(save_dir,
                                                'save_RF_cls_result_' + e_name + '_CV_' + str(int(CVNum)) + '.json')
                            self.Savejosn(cls_Result, name)
                            self.Result_Tabel(fina_result)
                        if self.radioButton_split.isChecked():
                            train_idx, test_idx, Label_test, Label_train, Data_test, Data_train = \
                                split_result['train_idx'], split_result['test_idx'], split_result['Label_test'], \
                                split_result['Label_train'], split_result['Data_test'], split_result['Data_train']
                            Pred, Prob, Metric = self.RandomClssification(Label_test, Label_train, Data_test, Data_train)
                            if np.all((label_t == -1) | (label_t == 1)):
                                Pred[Pred == 0] = -1
                                Label_test[Label_test == 0] = -1
                            self.ground_truth, self.cls_Prob, self.cls_Pred = Label_test, Prob, Pred
                            cls_Result = {'train_idx':train_idx, 'test_idx':test_idx,
                                          'pred':Pred.tolist(), 'AUC':Metric[0], 'ACC':Metric[1], 'SEN':Metric[2],
                                          'SPE':Metric[3], 'PRE':Metric[4], 'F1':Metric[5], 'BAC':Metric[6]}
                            fina_result = {'Area under the ROC curve': Metric[0], 'Accuracy': Metric[1],
                                           'Sensitive': Metric[2], 'Specificity': Metric[3],
                                           'Precision': Metric[4], 'F1-score': Metric[5],
                                           'Balanced accuracy': Metric[6]}
                            name = os.path.join(save_dir,
                                                'save_RF_cls_result_' + e_name + '_training_ratio_' + str(
                                                    float(self.lineEdit_train.text()) / 100.) + '.json')
                            self.Savejosn(cls_Result, name)
                            self.Result_Tabel_2(fina_result)

                    elif Classifier.text() == "Extreme Gradient Boosting (XGBoost)":
                        if self.radioButton_CV.isChecked():
                            cls_Result = []
                            cls_Prob = []
                            cls_Pred = []
                            ground_truth = []
                            for f, split in enumerate(split_result):
                                train_idx, test_idx, Label_test, Label_train, Data_test, Data_train = \
                                    split['train_idx'], split['test_idx'], split['Label_test'], split['Label_train'], \
                                    split['Data_test'], split['Data_train']
                                Pred, Prob, Metric = self.XGBClssification(Label_test, Label_train, Data_test, Data_train)
                                if np.all((label_t == -1) | (label_t == 1)):
                                    Pred[Pred == 0] = -1
                                    Label_test[Label_test == 0] = -1
                                cls_Prob.append(Prob)
                                cls_Pred.append(Pred)
                                ground_truth.append(Label_test)
                                cls_Result.append({'fold': f, 'train_idx': train_idx.tolist(),
                                                   'test_idx': test_idx.tolist(), 'pred': Pred.tolist(),
                                                   'AUC': Metric[0], 'ACC': Metric[1], 'SEN': Metric[2],
                                                   'SPE': Metric[3], 'PRE': Metric[4], 'F1': Metric[5],
                                                   'BAC': Metric[6]})
                            self.cls_Prob = np.concatenate(cls_Prob, axis=0)
                            self.cls_Pred = np.concatenate(cls_Pred, axis=0)
                            self.ground_truth = np.concatenate(ground_truth, axis=0)
                            fina_result = self.Calculate_final_result_cls(cls_Result)
                            cls_Result.append(
                                {'final_result': '[mean, std]', 'AUC': fina_result['Area under the ROC curve'],
                                 'ACC': fina_result['Accuracy'],
                                 'SEN': fina_result['Sensitive'], 'SPE': fina_result['Specificity'],
                                 'PRE': fina_result['Precision'],
                                 'F1': fina_result['F1-score'], 'BAC': fina_result['Balanced accuracy']})
                            name = os.path.join(save_dir,
                                                'save_XGB_cls_result_' + e_name + '_CV_' + str(int(CVNum)) + '.json')
                            self.Savejosn(cls_Result, name)
                            self.Result_Tabel(fina_result)
                        if self.radioButton_split.isChecked():
                            train_idx, test_idx, Label_test, Label_train, Data_test, Data_train = \
                                split_result['train_idx'], split_result['test_idx'], split_result['Label_test'], \
                                split_result['Label_train'], split_result['Data_test'], split_result['Data_train']
                            Pred, Prob, Metric = self.XGBClssification(Label_test, Label_train, Data_test, Data_train)
                            if np.all((label_t == -1) | (label_t == 1)):
                                Pred[Pred == 0] = -1
                                Label_test[Label_test == 0] = -1
                            self.ground_truth, self.cls_Prob, self.cls_Pred = Label_test, Prob, Pred
                            cls_Result = {'train_idx':train_idx, 'test_idx':test_idx,
                                          'pred':Pred.tolist(), 'AUC':Metric[0], 'ACC':Metric[1], 'SEN':Metric[2],
                                          'SPE':Metric[3], 'PRE':Metric[4], 'F1':Metric[5], 'BAC':Metric[6]}
                            fina_result = {'Area under the ROC curve': Metric[0], 'Accuracy': Metric[1],
                                           'Sensitive': Metric[2], 'Specificity': Metric[3],
                                           'Precision': Metric[4], 'F1-score': Metric[5],
                                           'Balanced accuracy': Metric[6]}
                            name = os.path.join(save_dir,
                                                'save_XGB_cls_result_' + e_name + '_training_ratio_' + str(
                                                    float(self.lineEdit_train.text()) / 100.) + '.json')
                            self.Savejosn(cls_Result, name)
                            self.Result_Tabel_2(fina_result)

                    elif Classifier.text() == "K-Nearest Neighbors (KNN)":
                        if self.radioButton_CV.isChecked():
                            cls_Result = []
                            cls_Prob = []
                            cls_Pred = []
                            ground_truth = []
                            for f, split in enumerate(split_result):
                                train_idx, test_idx, Label_test, Label_train, Data_test, Data_train = \
                                    split['train_idx'], split['test_idx'], split['Label_test'], split['Label_train'], \
                                    split['Data_test'], split['Data_train']
                                if len(Label_train) < 5: nb = len(Label_train)
                                else: nb = 5
                                Pred, Prob, Metric = self.KNeighborClssification(Label_test, Label_train, Data_test, Data_train, nb)
                                if np.all((label_t == -1) | (label_t == 1)):
                                    Pred[Pred == 0] = -1
                                    Label_test[Label_test == 0] = -1
                                cls_Prob.append(Prob)
                                cls_Pred.append(Pred)
                                ground_truth.append(Label_test)
                                cls_Result.append({'fold': f, 'train_idx': train_idx.tolist(),
                                                   'test_idx': test_idx.tolist(), 'pred': Pred.tolist(),
                                                   'AUC': Metric[0], 'ACC': Metric[1], 'SEN': Metric[2],
                                                   'SPE': Metric[3], 'PRE': Metric[4], 'F1': Metric[5],
                                                   'BAC': Metric[6]})
                            self.cls_Prob = np.concatenate(cls_Prob, axis=0)
                            self.cls_Pred = np.concatenate(cls_Pred, axis=0)
                            self.ground_truth = np.concatenate(ground_truth, axis=0)
                            fina_result = self.Calculate_final_result_cls(cls_Result)
                            cls_Result.append(
                                {'final_result': '[mean, std]', 'AUC': fina_result['Area under the ROC curve'],
                                 'ACC': fina_result['Accuracy'],
                                 'SEN': fina_result['Sensitive'], 'SPE': fina_result['Specificity'],
                                 'PRE': fina_result['Precision'],
                                 'F1': fina_result['F1-score'], 'BAC': fina_result['Balanced accuracy']})
                            name = os.path.join(save_dir,
                                                'save_KNN_cls_result_' + e_name + '_CV_' + str(int(CVNum)) + '.json')
                            self.Savejosn(cls_Result, name)
                            self.Result_Tabel(fina_result)
                        if self.radioButton_split.isChecked():
                            train_idx, test_idx, Label_test, Label_train, Data_test, Data_train = \
                                split_result['train_idx'], split_result['test_idx'], split_result['Label_test'], \
                                split_result['Label_train'], split_result['Data_test'], split_result['Data_train']
                            if len(Label_train) < 5: nb = len(Label_train)
                            else: nb = 5
                            Pred, Prob, Metric = self.KNeighborClssification(Label_test, Label_train, Data_test, Data_train, nb)
                            if np.all((label_t == -1) | (label_t == 1)):
                                Pred[Pred == 0] = -1
                                Label_test[Label_test == 0] = -1
                            self.ground_truth, self.cls_Prob, self.cls_Pred = Label_test, Prob, Pred
                            cls_Result = {'train_idx':train_idx, 'test_idx':test_idx,
                                          'pred':Pred.tolist(), 'AUC':Metric[0], 'ACC':Metric[1], 'SEN':Metric[2],
                                          'SPE':Metric[3], 'PRE':Metric[4], 'F1':Metric[5], 'BAC':Metric[6]}
                            fina_result = {'Area under the ROC curve': Metric[0], 'Accuracy': Metric[1],
                                           'Sensitive': Metric[2], 'Specificity': Metric[3],
                                           'Precision': Metric[4], 'F1-score': Metric[5],
                                           'Balanced accuracy': Metric[6]}
                            name = os.path.join(save_dir,
                                                'save_KNN_cls_result_' + e_name + '_training_ratio_' + str(
                                                    float(self.lineEdit_train.text()) / 100.) + '.json')
                            self.Savejosn(cls_Result, name)
                            self.Result_Tabel_2(fina_result)

                    elif Classifier.text() == "Self-Defined Algorithm:":
                        dill.settings['recurse'] = True
                        with open(self.lineEdit_load_MDA.text(), 'rb') as f:
                            alg_fun = dill.load(f)
                        if self.radioButton_CV.isChecked():
                            cls_Result = []
                            cls_Prob = []
                            cls_Pred = []
                            ground_truth = []
                            for f, split in enumerate(split_result):
                                train_idx, test_idx, Label_test, Label_train, Data_test, Data_train = \
                                    split['train_idx'], split['test_idx'], split['Label_test'], split['Label_train'], \
                                    split['Data_test'], split['Data_train']
                                Pred, Prob = alg_fun(Label_train, Data_test, Data_train)
                                Metric = self.ClassificationMetric(Label_test, Pred, Prob)
                                if np.all((label_t == -1) | (label_t == 1)):
                                    Pred[Pred == 0] = -1
                                    Label_test[Label_test == 0] = -1
                                cls_Prob.append(Prob)
                                cls_Pred.append(Pred)
                                ground_truth.append(Label_test)
                                cls_Result.append({'fold': f, 'train_idx': train_idx.tolist(),
                                                   'test_idx': test_idx.tolist(), 'pred': Pred.tolist(),
                                                   'AUC': Metric[0], 'ACC': Metric[1], 'SEN': Metric[2],
                                                   'SPE': Metric[3], 'PRE': Metric[4], 'F1': Metric[5],
                                                   'BAC': Metric[6]})
                            self.cls_Prob = np.concatenate(cls_Prob, axis=0)
                            self.cls_Pred = np.concatenate(cls_Pred, axis=0)
                            self.ground_truth = np.concatenate(ground_truth, axis=0)
                            fina_result = self.Calculate_final_result_cls(cls_Result)
                            cls_Result.append(
                                {'final_result': '[mean, std]', 'AUC': fina_result['Area under the ROC curve'],
                                 'ACC': fina_result['Accuracy'],
                                 'SEN': fina_result['Sensitive'], 'SPE': fina_result['Specificity'],
                                 'PRE': fina_result['Precision'],
                                 'F1': fina_result['F1-score'], 'BAC': fina_result['Balanced accuracy']})
                            name = os.path.join(save_dir,
                                                'save_custom_cls_result_' + e_name + '_CV_' + str(int(CVNum)) + '.json')
                            self.Savejosn(cls_Result, name)
                            self.Result_Tabel(fina_result)
                        if self.radioButton_split.isChecked():
                            train_idx, test_idx, Label_test, Label_train, Data_test, Data_train = \
                                split_result['train_idx'], split_result['test_idx'], split_result['Label_test'], \
                                split_result['Label_train'], split_result['Data_test'], split_result['Data_train']
                            Pred, Prob = alg_fun(Label_train, Data_test, Data_train)
                            Metric = self.ClassificationMetric(Label_test, Pred, Prob)
                            if np.all((label_t == -1) | (label_t == 1)):
                                Pred[Pred == 0] = -1
                                Label_test[Label_test == 0] = -1
                            self.ground_truth, self.cls_Prob, self.cls_Pred = Label_test, Prob, Pred
                            cls_Result = {'train_idx': train_idx, 'test_idx': test_idx,
                                          'pred': Pred.tolist(), 'AUC': Metric[0], 'ACC': Metric[1], 'SEN': Metric[2],
                                          'SPE': Metric[3], 'PRE': Metric[4], 'F1': Metric[5], 'BAC': Metric[6]}
                            fina_result = {'Area under the ROC curve': Metric[0], 'Accuracy': Metric[1],
                                           'Sensitive': Metric[2], 'Specificity': Metric[3],
                                           'Precision': Metric[4], 'F1-score': Metric[5],
                                           'Balanced accuracy': Metric[6]}
                            name = os.path.join(save_dir,
                                                'save_custom_cls_result_' + e_name + '_training_ratio_' + str(
                                                    float(self.lineEdit_train.text()) / 100.) + '.json')
                            self.Savejosn(cls_Result, name)
                            self.Result_Tabel_2(fina_result)

        elif self.radioButton_reg.isChecked():
            for Classifier in Classifier_list:
                if Classifier.isChecked():
                    if Classifier.text() == "Support Vector Regression (SVR)":
                        if self.radioButton_CV.isChecked():
                            cls_Result = []
                            for f, split in enumerate(split_result):
                                train_idx, test_idx, Label_test, Label_train, Data_test, Data_train = \
                                    split['train_idx'], split['test_idx'], split['Label_test'], split['Label_train'], \
                                    split['Data_test'], split['Data_train']
                                Pred, Metric = self.SVMRegression(Label_test, Label_train, Data_test, Data_train)
                                cls_Result.append({'fold':f, 'train_idx':train_idx.tolist(),
                                                   'test_idx':test_idx.tolist(), 'pred':Pred.tolist(),
                                                   'MAE':Metric[0], 'MSE':Metric[1], 'CC':Metric[2]})
                            fina_result = self.Calculate_final_result_reg(cls_Result)
                            cls_Result.append(
                                {'final_result': '[mean, std]', 'MAE': fina_result['Mean absolute error'],
                                 'MSE': fina_result['Mean squared error'], 'CC': fina_result['Concordance correlation coefficient']})
                            name = os.path.join(save_dir,
                                                'save_SVR_reg_result_' + e_name + '_CV_' + str(int(CVNum)) + '.json')
                            self.Savejosn(cls_Result, name)
                            self.Result_Tabel(fina_result)
                        if self.radioButton_split.isChecked():
                            train_idx, test_idx, Label_test, Label_train, Data_test, Data_train = \
                                split_result['train_idx'], split_result['test_idx'], split_result['Label_test'], \
                                split_result['Label_train'], split_result['Data_test'], split_result['Data_train']
                            Pred, Metric = self.SVMRegression(Label_test, Label_train, Data_test, Data_train)
                            cls_Result = {'train_idx':train_idx, 'test_idx':test_idx,
                                          'pred':Pred.tolist(), 'MAE':Metric[0], 'MSE':Metric[1], 'CC':Metric[2]}
                            fina_result = {'Mean absolute error': Metric[0], 'Mean squared error': Metric[1], 'Concordance correlation coefficient': Metric[2]}
                            name = os.path.join(save_dir,
                                                'save_SVR_reg_result_' + e_name + '_training_ratio_' + str(float(self.lineEdit_train.text())/100.) + '.json')
                            self.Savejosn(cls_Result, name)
                            self.Result_Tabel_2(fina_result)

                    elif Classifier.text() == "Random Forest (RF)":
                        if self.radioButton_CV.isChecked():
                            cls_Result = []
                            for f, split in enumerate(split_result):
                                train_idx, test_idx, Label_test, Label_train, Data_test, Data_train = \
                                    split['train_idx'], split['test_idx'], split['Label_test'], split['Label_train'], \
                                    split['Data_test'], split['Data_train']
                                Pred, Metric = self.RandomRegression(Label_test, Label_train, Data_test, Data_train)
                                cls_Result.append({'fold':f, 'train_idx':train_idx.tolist(),
                                                   'test_idx':test_idx.tolist(), 'pred':Pred.tolist(),
                                                   'MAE':Metric[0], 'MSE':Metric[1], 'CC':Metric[2]})
                            fina_result = self.Calculate_final_result_reg(cls_Result)
                            cls_Result.append(
                                {'final_result': '[mean, std]', 'MAE': fina_result['Mean absolute error'],
                                 'MSE': fina_result['Mean squared error'],
                                 'CC': fina_result['Concordance correlation coefficient']})
                            name = os.path.join(save_dir,
                                                'save_RF_reg_result_' + e_name + '_CV_' + str(int(CVNum)) + '.json')
                            self.Savejosn(cls_Result, name)
                            self.Result_Tabel(fina_result)
                        if self.radioButton_split.isChecked():
                            train_idx, test_idx, Label_test, Label_train, Data_test, Data_train = \
                                split_result['train_idx'], split_result['test_idx'], split_result['Label_test'], \
                                split_result['Label_train'], split_result['Data_test'], split_result['Data_train']
                            Pred, Metric = self.RandomRegression(Label_test, Label_train, Data_test, Data_train)
                            cls_Result = {'train_idx':train_idx, 'test_idx':test_idx,
                                          'pred':Pred.tolist(), 'MAE':Metric[0], 'MSE':Metric[1], 'CC':Metric[2]}
                            fina_result = {'Mean absolute error': Metric[0], 'Mean squared error': Metric[1], 'Concordance correlation coefficient': Metric[2]}
                            name = os.path.join(save_dir,
                                                'save_RF_reg_result_' + e_name + '_training_ratio_' + str(
                                                    float(self.lineEdit_train.text()) / 100.) + '.json')
                            self.Savejosn(cls_Result, name)
                            self.Result_Tabel_2(fina_result)

                    elif Classifier.text() == "Extreme Gradient Boosting (XGBoost)":
                        if self.radioButton_CV.isChecked():
                            cls_Result = []
                            for f, split in enumerate(split_result):
                                train_idx, test_idx, Label_test, Label_train, Data_test, Data_train = \
                                    split['train_idx'], split['test_idx'], split['Label_test'], split['Label_train'], \
                                    split['Data_test'], split['Data_train']
                                Pred, Metric = self.XGBRegression(Label_test, Label_train, Data_test, Data_train)
                                cls_Result.append({'fold':f, 'train_idx':train_idx.tolist(),
                                                   'test_idx':test_idx.tolist(), 'pred':Pred.tolist(),
                                                   'MAE':Metric[0], 'MSE':Metric[1], 'CC':Metric[2]})
                            fina_result = self.Calculate_final_result_reg(cls_Result)
                            cls_Result.append(
                                {'final_result': '[mean, std]', 'MAE': fina_result['Mean absolute error'],
                                 'MSE': fina_result['Mean squared error'],
                                 'CC': fina_result['Concordance correlation coefficient']})
                            name = os.path.join(save_dir,
                                                'save_XGB_reg_result_' + e_name + '_CV_' + str(int(CVNum)) + '.json')
                            self.Savejosn(cls_Result, name)
                            self.Result_Tabel(fina_result)
                        if self.radioButton_split.isChecked():
                            train_idx, test_idx, Label_test, Label_train, Data_test, Data_train = \
                                split_result['train_idx'], split_result['test_idx'], split_result['Label_test'], \
                                split_result['Label_train'], split_result['Data_test'], split_result['Data_train']
                            Pred, Metric = self.XGBRegression(Label_test, Label_train, Data_test, Data_train)
                            cls_Result = {'train_idx':train_idx, 'test_idx':test_idx,
                                          'pred':Pred.tolist(), 'MAE':Metric[0], 'MSE':Metric[1], 'CC':Metric[2]}
                            fina_result = {'Mean absolute error': Metric[0], 'Mean squared error': Metric[1], 'Concordance correlation coefficient': Metric[2]}
                            name = os.path.join(save_dir,
                                                'save_XGB_reg_result_' + e_name + '_training_ratio_' + str(
                                                    float(self.lineEdit_train.text()) / 100.) + '.json')
                            self.Savejosn(cls_Result, name)
                            self.Result_Tabel_2(fina_result)

                    elif Classifier.text() == "K-Nearest Neighbors (KNN)":
                        if self.radioButton_CV.isChecked():
                            cls_Result = []
                            for f, split in enumerate(split_result):
                                train_idx, test_idx, Label_test, Label_train, Data_test, Data_train = \
                                    split['train_idx'], split['test_idx'], split['Label_test'], split['Label_train'], \
                                    split['Data_test'], split['Data_train']
                                if len(Label_train) < 5: nb = len(Label_train)
                                else: nb = 5
                                Pred, Metric = self.KNeighborsRegression(Label_test, Label_train, Data_test, Data_train, nb)
                                cls_Result.append({'fold':f, 'train_idx':train_idx.tolist(),
                                                   'test_idx':test_idx.tolist(), 'pred':Pred.tolist(),
                                                   'MAE':Metric[0], 'MSE':Metric[1], 'CC':Metric[2]})
                            fina_result = self.Calculate_final_result_reg(cls_Result)
                            cls_Result.append(
                                {'final_result': '[mean, std]', 'MAE': fina_result['Mean absolute error'],
                                 'MSE': fina_result['Mean squared error'],
                                 'CC': fina_result['Concordance correlation coefficient']})
                            name = os.path.join(save_dir,
                                                'save_KNN_reg_result_' + e_name + '_CV_' + str(int(CVNum)) + '.json')
                            self.Savejosn(cls_Result, name)
                            self.Result_Tabel(fina_result)
                        if self.radioButton_split.isChecked():
                            train_idx, test_idx, Label_test, Label_train, Data_test, Data_train = \
                                split_result['train_idx'], split_result['test_idx'], split_result['Label_test'], \
                                split_result['Label_train'], split_result['Data_test'], split_result['Data_train']
                            if len(Label_train) < 5: nb = len(Label_train)
                            else: nb = 5
                            Pred, Metric = self.KNeighborsRegression(Label_test, Label_train, Data_test, Data_train, nb)
                            cls_Result = {'train_idx':train_idx, 'test_idx':test_idx,
                                          'pred':Pred.tolist(), 'MAE':Metric[0], 'MSE':Metric[1], 'CC':Metric[2]}
                            fina_result = {'Mean absolute error': Metric[0], 'Mean squared error': Metric[1], 'Concordance correlation coefficient': Metric[2]}
                            name = os.path.join(save_dir,
                                                'save_KNN_reg_result_' + e_name + '_training_ratio_' + str(
                                                    float(self.lineEdit_train.text()) / 100.) + '.json')
                            self.Savejosn(cls_Result, name)
                            self.Result_Tabel_2(fina_result)

                    elif Classifier.text() == "Self-Defined Algorithm:":
                        dill.settings['recurse'] = True
                        with open(self.lineEdit_load_MDA.text(), 'rb') as f:
                            alg_fun = dill.load(f)
                        if self.radioButton_CV.isChecked():
                            cls_Result = []
                            for f, split in enumerate(split_result):
                                train_idx, test_idx, Label_test, Label_train, Data_test, Data_train = \
                                    split['train_idx'], split['test_idx'], split['Label_test'], split['Label_train'], \
                                    split['Data_test'], split['Data_train']
                                Pred = alg_fun(Label_train, Data_test, Data_train)
                                Metric = self.RegressionMetric(Label_test, Pred)
                                cls_Result.append({'fold': f, 'train_idx': train_idx.tolist(),
                                                   'test_idx': test_idx.tolist(), 'pred': Pred.tolist(),
                                                   'MAE': Metric[0], 'MSE': Metric[1], 'CC': Metric[2]})
                            fina_result = self.Calculate_final_result_reg(cls_Result)
                            cls_Result.append(
                                {'final_result': '[mean, std]', 'MAE': fina_result['Mean absolute error'],
                                 'MSE': fina_result['Mean squared error'],
                                 'CC': fina_result['Concordance correlation coefficient']})
                            name = os.path.join(save_dir,
                                                'save_custom_reg_result_' + e_name + '_CV_' + str(int(CVNum)) + '.json')
                            self.Savejosn(cls_Result, name)
                            self.Result_Tabel(fina_result)
                        if self.radioButton_split.isChecked():
                            train_idx, test_idx, Label_test, Label_train, Data_test, Data_train = \
                                split_result['train_idx'], split_result['test_idx'], split_result['Label_test'], \
                                split_result['Label_train'], split_result['Data_test'], split_result['Data_train']
                            Pred = alg_fun(Label_train, Data_test, Data_train)
                            Metric = self.RegressionMetric(Label_test, Pred)
                            cls_Result = {'train_idx': train_idx, 'test_idx': test_idx,
                                          'pred': Pred.tolist(), 'MAE': Metric[0], 'MSE': Metric[1], 'CC': Metric[2]}
                            fina_result = {'Mean absolute error': Metric[0], 'Mean squared error': Metric[1],
                                           'Concordance correlation coefficient': Metric[2]}
                            name = os.path.join(save_dir,
                                                'save_custom_reg_result_' + e_name + '_training_ratio_' + str(
                                                    float(self.lineEdit_train.text()) / 100.) + '.json')
                            self.Savejosn(cls_Result, name)
                            self.Result_Tabel_2(fina_result)

        # Finished
        # running_box.reject()
        running_box.close()
        QMessageBox.information(self, "Successful", "Model execution complete! ")


    def Vis_ROC(self):
        if self.ground_truth is None or self.cls_Prob is None:
            QMessageBox.critical(self, "Error", "Please run first. ")
            return
        roc_curve_dialog = ROC_Curve_Dialog(self.ground_truth, self.cls_Prob, self)
        roc_curve_dialog.exec_()

    def Vis_CM(self):
        if self.ground_truth is None or self.cls_Pred is None:
            QMessageBox.critical(self, "Error", "Please run first. ")
            return
        confusion_matrix_dialog = Confusion_Matrix_Dialog(self.ground_truth, self.cls_Pred, self.ne, self)
        confusion_matrix_dialog.exec_()

    def PCA(self, data, save_dir, PCA_dim):
        if PCA_dim.is_integer(): pca = PCA(n_components=int(PCA_dim))
        else: pca = PCA(n_components=PCA_dim)
        r = pca.fit_transform(data)
        if PCA_dim.is_integer():
            np.save(os.path.join(save_dir, 'save_PCA_fea_reduced_dim_' + str(int(PCA_dim)) + '.npy'), r)
        else:
            np.save(os.path.join(save_dir, 'save_PCA_fea_reduced_dim_' + str(PCA_dim) + '.npy'), r)
        return r

    # def ICA(self, data, save_dir, ICA_dim):
    #     ica = FastICA(n_components=int(ICA_dim))
    #     r = ica.fit_transform(data)
    #     np.save(os.path.join(save_dir, 'save_ICA_fea_reduced_dim_' + str(int(ICA_dim)) + '.npy'), r)
    #     return r
    #
    # def CCA(self, data, save_dir, CCA_dim):
    #     cca = CCA(n_components=int(CCA_dim))
    #     cca.fit(data, data)
    #     r = cca.transform(data)
    #     np.save(os.path.join(save_dir, 'save_CCA_fea_reduced_dim_' + str(int(CCA_dim)) + '.npy'), r)
    #     return r

    def UFS(self, data, label, save_dir, UFS_dim):
        ufs = SelectKBest(score_func=f_classif, k=int(UFS_dim))
        r = ufs.fit_transform(data, label)
        np.save(os.path.join(save_dir, 'save_UFS_fea_reduced_dim_' + str(int(UFS_dim)) + '.npy'), r)
        return r

    def Ttest(self, data, label, save_dir, Ttest_dim):
        num_samples, num_features = data.shape
        p_values = []
        for feature_idx in range(num_features):
            feature_values_class_1 = data[label == 0, feature_idx]
            feature_values_class_2 = data[label == 1, feature_idx]
            t_stat, p_value = ttest_ind(feature_values_class_1, feature_values_class_2)
            p_values.append((feature_idx, p_value))
        p_values.sort(key=lambda x: x[1])
        top_n_features = [feature_idx for feature_idx, p_value in p_values[:int(Ttest_dim)]]
        r = data[:, top_n_features]
        np.save(os.path.join(save_dir, 'save_Ttest_fea_reduced_dim_' + str(int(Ttest_dim)) + '.npy'), r)
        return r

    def DataSplit_CV(self, Data, Label, k):
        kf = KFold(n_splits=k, shuffle=True)
        split_result = []
        for train_index, test_index in kf.split(Data):
            random.shuffle(train_index)
            random.shuffle(test_index)
            Data_train, Data_test = Data[train_index, :], Data[test_index, :]
            Label_train, Label_test = Label[train_index], Label[test_index]
            split_result.append({'train_idx': train_index, 'test_idx': test_index,
                                 'Label_test': Label_test, 'Label_train': Label_train,
                                 'Data_test': Data_test, 'Data_train': Data_train})
        return split_result

    def DataSplit_ratio(self, Data, Label, ratio):
        index = [i for i in range(len(Label))]
        split_index = int(len(index) * ratio)
        random.shuffle(index)
        train_idx = index[:split_index]
        test_idx = index[split_index:]
        if len(train_idx) == 0:
            train_idx = [random.choice(index)]
            test_idx = list(set(index) - set(train_idx))
            random.shuffle(test_idx)
        elif len(test_idx) == 0:
            test_idx = [random.choice(index)]
            train_idx = list(set(index) - set(test_idx))
            random.shuffle(train_idx)
        return {'train_idx': train_idx, 'test_idx': test_idx,
                'Label_test': Label[test_idx], 'Label_train': Label[train_idx],
                'Data_test': Data[test_idx, :], 'Data_train': Data[train_idx, :]}

    def Savejosn(self, data, file_name):
        json_str = json.dumps(data)
        with open(file_name, "w") as josn_file:
            josn_file.write(json_str)

    def _None(self, list):
        if not None in list:
            return np.mean(list), np.std(list)
        else: return None, None

    def Calculate_final_result_cls(self, result_list):
        AUC, ACC, SEN, SPE, PRE, F1, BAC = [], [], [], [], [], [], []
        for dict in result_list:
            AUC.append(dict['AUC'])
            ACC.append(dict['ACC'])
            SEN.append(dict['SEN'])
            SPE.append(dict['SPE'])
            PRE.append(dict['PRE'])
            F1.append(dict['F1'])
            BAC.append(dict['BAC'])
        AUC, ACC, SEN, SPE = self._None(AUC), self._None(ACC), self._None(SEN), self._None(SPE)
        PRE, F1, BAC = self._None(PRE), self._None(F1), self._None(BAC)
        return {'Area under the ROC curve': AUC, 'Accuracy': ACC, 'Sensitive':SEN, 'Specificity':SPE, 'Precision':PRE, 'F1-score':F1, 'Balanced accuracy':BAC}

    def Calculate_final_result_reg(self, result_list):
        MAE, MSE, CC = [], [], []
        for dict in result_list:
            MAE.append(dict['MAE'])
            MSE.append(dict['MSE'])
            CC.append(dict['CC'])
        MAE, MSE, CC = self._None(MAE), self._None(MSE), self._None(CC)
        return {'Mean absolute error': MAE, 'Mean squared error': MSE, 'Concordance correlation coefficient':CC}

    def Result_Tabel(self, dict):
        self.tableWidget_result.setRowCount(2)
        self.tableWidget_result.setColumnCount(len(dict))
        for i, key in enumerate(dict.keys()):
            item = QTableWidgetItem(str(round(dict[key][0], 5)))
            item.setTextAlignment(Qt.AlignCenter)
            self.tableWidget_result.setItem(0, i, item)
            item = QTableWidgetItem(str(round(dict[key][1], 5)))
            item.setTextAlignment(Qt.AlignCenter)
            self.tableWidget_result.setItem(1, i, item)
            header = QTableWidgetItem(key)
            self.tableWidget_result.setHorizontalHeaderItem(i, header)
        self.tableWidget_result.setVerticalHeaderItem(0, QTableWidgetItem('Mean'))
        self.tableWidget_result.setVerticalHeaderItem(1, QTableWidgetItem('Standard deviation'))
        self.tableWidget_result.horizontalHeader().setDefaultAlignment(Qt.AlignCenter)
        self.tableWidget_result.verticalHeader().setDefaultAlignment(Qt.AlignCenter)
        self.tableWidget_result.setShowGrid(True)

    def Result_Tabel_2(self, dict):
        self.tableWidget_result.setRowCount(1)
        self.tableWidget_result.setColumnCount(len(dict))
        headers = list(dict.keys())
        self.tableWidget_result.setHorizontalHeaderLabels(headers)
        for col, key in enumerate(headers):
            item = QTableWidgetItem(str(round(dict[key], 5)))
            item.setTextAlignment(Qt.AlignCenter)
            self.tableWidget_result.setItem(0, col, item)
        self.tableWidget_result.setVerticalHeaderItem(0, QTableWidgetItem('value'))
        self.tableWidget_result.horizontalHeader().setDefaultAlignment(Qt.AlignCenter)
        self.tableWidget_result.verticalHeader().setDefaultAlignment(Qt.AlignCenter)
        self.tableWidget_result.setShowGrid(True)

    def ClassificationMetric(self, Label_test, Label_pred, Prob):
        AUC = roc_auc_score(Label_test, Prob)
        ACC = accuracy_score(Label_test, Label_pred)
        SEN = recall_score(Label_test, Label_pred)
        tn, fp, fn, tp = confusion_matrix(Label_test, Label_pred).ravel()
        SPE = tn / (tn + fp)
        PRE = precision_score(Label_test, Label_pred)
        F1 = f1_score(Label_test, Label_pred)
        BAC = balanced_accuracy_score(Label_test, Label_pred)
        return AUC, ACC, SEN, SPE, PRE, F1, BAC

    def RegressionMetric(self, Label_test, Label_pred):
        MAE = mean_absolute_error(Label_test, Label_pred)
        MSE = mean_squared_error(Label_test, Label_pred)
        CC = np.corrcoef(Label_test, Label_pred)[0, 1]
        return MAE, MSE, CC

    def SVMClssification(self, Label_test, Label_train, Data_test, Data_train):
        model = SVC(probability=True)
        model.fit(Data_train, Label_train)
        Label_pred = model.predict(Data_test)
        Prob = model.predict_proba(Data_test)[:, 1]
        Metric = self.ClassificationMetric(Label_test, Label_pred, Prob)
        return Label_pred, Prob, Metric

    def RandomClssification(self, Label_test, Label_train, Data_test, Data_train):
        model = RandomForestClassifier()
        model.fit(Data_train, Label_train)
        Label_pred = model.predict(Data_test)
        Prob = model.predict_proba(Data_test)[:, 1]
        Metric = self.ClassificationMetric(Label_test, Label_pred, Prob)
        return Label_pred, Prob, Metric

    def XGBClssification(self, Label_test, Label_train, Data_test, Data_train):
        dtrain = xgb.DMatrix(Data_train, label=Label_train)
        dtest = xgb.DMatrix(Data_test)
        params = {'objective': 'binary:logistic'}
        num_rounds = 100
        model = xgb.train(params, dtrain, num_rounds)
        Label_prob = model.predict(dtest)
        Label_pred = np.round(Label_prob)
        Metric = self.ClassificationMetric(Label_test, Label_pred, Label_prob)
        return Label_pred, Label_prob, Metric

    def KNeighborClssification(self, Label_test, Label_train, Data_test, Data_train, n):
        model = KNeighborsClassifier(n_neighbors=n)
        model.fit(Data_train, Label_train)
        Label_pred = model.predict(Data_test)
        Prob = model.predict_proba(Data_test)[:, 1]
        Metric = self.ClassificationMetric(Label_test, Label_pred, Prob)
        return Label_pred, Prob, Metric

    def SVMRegression(self, Label_test, Label_train, Data_test, Data_train):
        model = SVR()
        model.fit(Data_train, Label_train)
        Label_pred = model.predict(Data_test)
        Metric = self.RegressionMetric(Label_test, Label_pred)
        return Label_pred, Metric

    def RandomRegression(self, Label_test, Label_train, Data_test, Data_train):
        model = RandomForestRegressor()
        model.fit(Data_train, Label_train)
        Label_pred = model.predict(Data_test)
        Metric = self.RegressionMetric(Label_test, Label_pred)
        return Label_pred, Metric

    def XGBRegression(self, Label_test, Label_train, Data_test, Data_train):
        model = xgb.XGBRegressor()
        model.fit(Data_train, Label_train)
        Label_pred = model.predict(Data_test)
        Metric = self.RegressionMetric(Label_test, Label_pred)
        return Label_pred, Metric

    def KNeighborsRegression(self, Label_test, Label_train, Data_test, Data_train, n):
        model = KNeighborsRegressor(n_neighbors=n)
        model.fit(Data_train, Label_train)
        Label_pred = model.predict(Data_test)
        Metric = self.RegressionMetric(Label_test, Label_pred)
        return Label_pred, Metric


    def Help(self):
        QMessageBox.about(self,
            "Help Info",
            "<p>  This module is to construct machine learning models for classification and regression. </p>"
            "<p>- Input data should be of size (S, F). </p>"
            "<p>- Input label for classification task should be organized with a shape of (S), with value being (0, 1) or (-1, 1). </p>"
            "<p>- Input label for regression task should be organized with a shape of (S). </p>"
            "<p>- Reduced Dimension should be a non-negative integer not exceeding min(S, F) for PAC and not exceeding F for UFS and T-test. For PCA, the Reduced Dimension can be a decimal range from 0 to 1. In this case, it represents the lowest cumulative contribution rate of principal component variance satisfied. </p>"
            "<p>  Symbol meaning: S is the number of subjects, F is the dimension of the features. </p>"
        )

    def CleaR(self):
        self.lineEdit_Browse_Data.clear()
        self.lineEdit_Browse_Label.clear()
        self.lineEdit_dim.clear()
        self.lineEdit_CV.clear()
        self.lineEdit_train.clear()
        self.lineEdit_test.clear()
        self.lineEdit_Browse_SaveDir.clear()
        self.tableWidget_result.clear()
        self.lineEdit_load_MDA.clear()
        self.ground_truth, self.cls_Prob, self.cls_Pred = None, None, None



class ROC_Curve_Dialog(QDialog):
    def __init__(self, y_true, y_pred_prob, parent=None):
        super(ROC_Curve_Dialog, self).__init__(parent)
        self.setWindowTitle("ROC Curve")
        self.layout = QVBoxLayout(self)
        self.figure = plt.figure()
        self.canvas = FigureCanvas(self.figure)
        self.layout.addWidget(self.canvas)
        self.plot_roc_curve(y_true, y_pred_prob)

    def plot_roc_curve(self, y_true, y_pred_prob):
        fpr, tpr, _ = roc_curve(y_true, y_pred_prob)

        ax = self.figure.add_subplot(111)
        ax.clear()
        ax.plot(fpr, tpr, 'b')
        ax.plot([0, 1], [0, 1],  'k--')
        ax.set_xlabel('False Positive Rate')
        ax.set_ylabel('True Positive Rate')
        self.canvas.draw()



class Confusion_Matrix_Dialog(QDialog):
    def __init__(self, y_true, y_pred, ne, parent=None):
        super(Confusion_Matrix_Dialog, self).__init__(parent)
        self.setWindowTitle("Confusion Matrix")
        self.layout = QVBoxLayout(self)
        self.figure = plt.figure()
        self.canvas = FigureCanvas(self.figure)
        self.layout.addWidget(self.canvas)
        self.plot_confusion_matrix(y_true, y_pred, ne)

    def plot_confusion_matrix(self, y_true, y_pred, ne=False):
        if ne == True: axis_label = [-1, 1]
        if ne == False: axis_label = [0, 1]
        cm = confusion_matrix(y_true, y_pred)

        ax = self.figure.add_subplot(111)
        ax.clear()
        disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=axis_label)
        disp.plot(ax=ax, cmap=plt.cm.Blues)
        self.canvas.draw()

