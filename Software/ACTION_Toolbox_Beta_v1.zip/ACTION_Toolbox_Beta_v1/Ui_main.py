import sys
from PyQt5.QtWidgets import *
from PyQt5.uic import loadUi
from PyQt5.QtCore import QUrl
from PyQt5.QtGui import QDesktopServices
from Ui_Main.BNC_Vis import Ui_BNC_Vis
from Ui_Main.DM_Met import Ui_DM_Met
from Ui_Main.BOLD_Aug import Ui_BOLD_Aug
from Ui_Main.Graph_Aug import Ui_Graph_Aug
from Ui_Main.CLM_Met import Ui_CLM_Met
from Ui_Main.BNFE import Ui_NFE
### Figure
import background_1_rc

class MainWindow(QMainWindow):
    def __init__(self, parent = None):
        super().__init__(parent)
        loadUi('./ui2/ui_Main.ui', self)

        self.setFixedSize(789, 848)

        self.menu1 = QMenu(self.pushButton_F_D_A)
        self.menu1.addAction("BOLD Signal Augmentation", self.BOLD_Aug)
        self.menu1.addAction("Graph Augmentation", self.Graph_Aug)
        self.pushButton_F_D_A.setMenu(self.menu1)

        self.menu2 = QMenu(self.pushButton_L_M_C)
        self.menu2.addAction("Machine Learning Model", self.CLM)
        self.menu2.addAction("Deep Learning-based Foundation Model", self.DM)
        self.pushButton_L_M_C.setMenu(self.menu2)

        self.pushButton_B_N_C.clicked.connect(self.show_BNC)
        self.pushButton_B_N_F_E.clicked.connect(self.show_BNFE)

        self.MANUAL.clicked.connect(self.URL)
        self.EXIT.clicked.connect(self.on_quitButton_clicked)

    def URL(self):
        QDesktopServices.openUrl(QUrl("https://github.com/mxliu/ACTION-Software-for-Functional-MRI-Analysis"))

    def on_quitButton_clicked(self):
        QApplication.quit()


    def setButtonStyle(self, index):
        btns = [self.pushButton_F_D_A, self.pushButton_L_M_C, self.pushButton_B_N_C, self.pushButton_B_N_F_E]
        for i, btn in enumerate(btns):
            if i == index:
                btn.setStyleSheet("QPushButton {\ncolor: rgb(197, 90, 17); \nbackground-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
                                            "stop: 0 #E8E8E8, stop: 0.5 #D3D3D3, stop: 1 #FFFFFF); \n border-radius: 0px;\n border-bottom: 2px solid gray;\n"
                                            " border-right: 2px solid gray;padding: 5px;} \n")
            else:
                btn.setStyleSheet("QPushButton {\ncolor:rgb(58, 78, 107); \nbackground-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
                                            "stop: 0 #E8E8E8, stop: 0.5 #D3D3D3, stop: 1 #FFFFFF); \n border-radius: 0px;\n border-bottom: 2px solid gray;\n"
                                            " border-right: 2px solid gray;padding: 5px;} \n"
                                            "QPushButton:hover {\n color: rgb(197, 90, 17);\n}"
                                            "QPushButton:pressed {border-top: 2px solid gray;\n border-left: 2px solid gray;\n"
                                            "border-bottom: 2px solid rgb(222, 222, 222);\n border-right: 2px solid rgb(222, 222, 222);} \n")

    def go_back_to_welcome(self):
        self.stackedWidget.setCurrentIndex(0)
        btns = [self.pushButton_F_D_A, self.pushButton_L_M_C, self.pushButton_B_N_C, self.pushButton_B_N_F_E]
        for i, btn in enumerate(btns):
            btn.setStyleSheet("QPushButton {\ncolor:rgb(58, 78, 107); \nbackground-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1,\n"
                                            "stop: 0 #E8E8E8, stop: 0.5 #D3D3D3, stop: 1 #FFFFFF); \n border-radius: 0px;\n border-bottom: 2px solid gray;\n"
                                            " border-right: 2px solid gray;padding: 5px;} \n"
                                            "QPushButton:hover {\n color: rgb(197, 90, 17);\n}"
                                            "QPushButton:pressed {border-top: 2px solid gray;\n border-left: 2px solid gray;\n"
                                            "border-bottom: 2px solid rgb(222, 222, 222);\n border-right: 2px solid rgb(222, 222, 222);} \n")

    def BOLD_Aug(self):
        self.setButtonStyle(0)
        self.BOLD_Aug = Ui_BOLD_Aug()
        self.BOLD_Aug.Cancel.clicked.connect(self.go_back_to_welcome)
        self.stackedWidget.addWidget(self.BOLD_Aug)
        self.stackedWidget.setCurrentWidget(self.BOLD_Aug)



    def Graph_Aug(self):
        self.setButtonStyle(0)
        self.Graph_Aug = Ui_Graph_Aug()
        self.Graph_Aug.Cancel.clicked.connect(self.go_back_to_welcome)
        self.stackedWidget.addWidget(self.Graph_Aug)
        self.stackedWidget.setCurrentWidget(self.Graph_Aug)

    def CLM(self):
        self.setButtonStyle(1)
        self.CLM = Ui_CLM_Met()
        self.CLM.Cancel.clicked.connect(self.go_back_to_welcome)
        self.stackedWidget.addWidget(self.CLM)
        self.stackedWidget.setCurrentWidget(self.CLM)

    def DM(self):
        self.setButtonStyle(1)
        self.DM = Ui_DM_Met()
        self.DM.Cancel.clicked.connect(self.go_back_to_welcome)
        self.stackedWidget.addWidget(self.DM)
        self.stackedWidget.setCurrentWidget(self.DM)

    def show_BNC(self):
        self.setButtonStyle(2)
        self.BNC_widget = Ui_BNC_Vis()
        self.BNC_widget.Cancel.clicked.connect(self.go_back_to_welcome)
        self.stackedWidget.addWidget(self.BNC_widget)
        self.stackedWidget.setCurrentWidget(self.BNC_widget)

    def show_BNFE(self):
        self.setButtonStyle(3)
        self.BNFE_widget = Ui_NFE()
        self.BNFE_widget.Cancel.clicked.connect(self.go_back_to_welcome)
        self.stackedWidget.addWidget(self.BNFE_widget)
        self.stackedWidget.setCurrentWidget(self.BNFE_widget)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())
