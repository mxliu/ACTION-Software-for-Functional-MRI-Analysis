from PyQt5.QtWidgets import *
from PyQt5.QtGui import QPixmap
from PyQt5.uic import loadUi
from PyQt5.QtCore import QUrl
from PyQt5.QtGui import QDesktopServices

class Ui_DM_Met(QDialog):
    def __init__(self):
        super(Ui_DM_Met, self).__init__()

        loadUi('./ui2/DM_Met.ui', self)
        self.label_backbone.setScaledContents(True)
        self.pretrain_process = QPixmap('./Image/fig_Framework.jpg')
        self.label_backbone.setPixmap(self.pretrain_process)

        self.alg_list = [self.radioButton_Transformer, self.radioButton_GAT, self.radioButton_GIN,
                         self.radioButton_GCN,  self.radioButton_BrainGNN, self.radioButton_GraphSAGE,
                         self.radioButton_STGCN, self.radioButton_MCGNN, self.radioButton_BrainNetCNN,
                         self.radioButton_STAGIN]
        self.fed_list = [self.radioButton_LGFedAvg, self.radioButton_FedAvg, self.radioButton_MOON,
                         self.radioButton_FedProx, self.radioButton_pFedMe]

        self.pushButton_Download.setEnabled(False)
        self.pushButton_FT.setEnabled(True)

        for radioButton in self.alg_list:
            radioButton.clicked.connect(self.handleRatioButtonClicked)

        for radioButton in self.fed_list:
            radioButton.clicked.connect(self.handleRatioButtonClicked1)

        self.pushButton_FT.clicked.connect(self.Fine_Tune)
        self.pushButton_Download.clicked.connect(self.Download)
        self.pushButton_Help.clicked.connect(self.Help)

    def handleRatioButtonClicked(self):
        clickedButton = self.sender()
        if clickedButton.text() in self.fed_list:
            self.pushButton_Download.setEnabled(False)
            self.pushButton_FT.setEnabled(True)
        else:
            self.pushButton_FT.setEnabled(True)
            self.pushButton_Download.setEnabled(False)

    def handleRatioButtonClicked1(self):
        clickedButton = self.sender()
        if clickedButton.text() in self.alg_list:
            self.pushButton_Download.setEnabled(True)
            self.pushButton_FT.setEnabled(False)
        else:
            self.pushButton_FT.setEnabled(False)
            self.pushButton_Download.setEnabled(True)

    def Fine_Tune(self):
        for alg in self.alg_list:
            if alg.isChecked():
                if alg.text() == "Graph Convolutional Network (GCN)":
                    QDesktopServices.openUrl(QUrl('https://github.com/mxliu/ACTION-Open-Source-Software-for-Functional-MRI-Analysis/tree/main/GCN'))

                elif alg.text() == "Transformer":
                    QDesktopServices.openUrl(QUrl('https://github.com/mxliu/ACTION-Open-Source-Software-for-Functional-MRI-Analysis/tree/main/Transformer'))

                elif alg.text() == "Graph Attention Network (GAT)":
                    QDesktopServices.openUrl(QUrl('https://github.com/mxliu/ACTION-Open-Source-Software-for-Functional-MRI-Analysis/tree/main/GAT'))

                elif alg.text() == "Modularity-constrained Graph Neural Network (MGNN)":
                    QDesktopServices.openUrl(QUrl('https://github.com/mxliu/ACTION-Open-Source-Software-for-Functional-MRI-Analysis/tree/main/MGNN'))

                elif alg.text() == "Graph SAmple and aggreGatE (GraphSAGE)":
                    QDesktopServices.openUrl(QUrl('https://github.com/mxliu/ACTION-Open-Source-Software-for-Functional-MRI-Analysis/tree/main/GraphSAGE'))

                elif alg.text() == "Spatio-Temporal Graph Convolutional Network (STGCN)":
                    QDesktopServices.openUrl(QUrl('https://github.com/mxliu/ACTION-Open-Source-Software-for-Functional-MRI-Analysis/tree/main/STGCN'))

                elif alg.text() == "Spatio-Temporal Attention Graph Isomorphism Network (STAGIN)":
                    QDesktopServices.openUrl(QUrl('https://github.com/mxliu/ACTION-Open-Source-Software-for-Functional-MRI-Analysis/tree/main/STAGIN'))

                elif alg.text() == "Brain Graph Neural Network (BrainGNN)":
                    QDesktopServices.openUrl(QUrl('https://github.com/mxliu/ACTION-Open-Source-Software-for-Functional-MRI-Analysis/tree/main/BrainGNN'))

                elif alg.text() == "Brain Network Convolutional Neural Network (BrainNetCNN)":
                    QDesktopServices.openUrl(QUrl('https://github.com/mxliu/ACTION-Open-Source-Software-for-Functional-MRI-Analysis/tree/main/BrainNetCNN'))

                elif alg.text() == "Graph Isomorphism Network (GIN)":
                    QDesktopServices.openUrl(QUrl('https://github.com/mxliu/ACTION-Open-Source-Software-for-Functional-MRI-Analysis/tree/main/GIN'))

    def Download(self):
        for fed in self.fed_list:
            if fed.isChecked():
                if fed.text() =="Local Global Federated Averaging (LGFedAvg)":
                    QDesktopServices.openUrl(QUrl('https://github.com/mxliu/ACTION-Open-Source-Software-for-Functional-MRI-Analysis/tree/main/LGFedAvg'))

                elif fed.text() =="Federated Averaging (FedAvg)":
                    QDesktopServices.openUrl(QUrl('https://github.com/mxliu/ACTION-Open-Source-Software-for-Functional-MRI-Analysis/tree/main/FedAvg'))

                elif fed.text() =="Model-Contrastive Federated Learning (MOON)":
                    QDesktopServices.openUrl(QUrl('https://github.com/mxliu/ACTION-Open-Source-Software-for-Functional-MRI-Analysis/tree/main/MOON'))

                elif fed.text() =="Federated Proximal (FedProx)":
                    QDesktopServices.openUrl(QUrl('https://github.com/mxliu/ACTION-Open-Source-Software-for-Functional-MRI-Analysis/tree/main/FedProx'))

                elif fed.text() =="Personalized Federated Learning with Moreau Envelopes (pFedMe)":
                    QDesktopServices.openUrl(QUrl('https://github.com/mxliu/ACTION-Open-Source-Software-for-Functional-MRI-Analysis/tree/main/pFedMe'))

    def Help(self):
        QMessageBox.about(self,
            "Help Info",
            "<p>- The toolbox only provides the deep model model as backbone encoder and federated learning strategy. </p>"
            "<p>- You can obtain pre-trained deep learning models on this function moudle by clicking the 'Fine-Tuning Process' button. </p>"
            "<p>- You can obtain the federated learning strategy by clicking the 'Source Code Link' button.  </p>"
        )

