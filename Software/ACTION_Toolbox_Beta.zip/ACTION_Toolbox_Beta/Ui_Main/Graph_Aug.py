from PyQt5 import QtWidgets
from PyQt5.QtWidgets import *
from PyQt5.uic import loadUi
from PyQt5.QtCore import QCoreApplication
import numpy as np
import torch
import random
import scipy.sparse as sp
import copy
import os
import dill

class Ui_Graph_Aug(QDialog):
    def __init__(self):
        super(Ui_Graph_Aug, self).__init__()

        loadUi('./ui2/Dialog_Graph_Aug.ui', self)
        self.pushButton_MDA.setEnabled(False)

        self.pushButton_Browse_AdjMatrix.clicked.connect(self.BrowseAdjMatrix)
        self.pushButton_Browse_NodeAttribute.clicked.connect(self.BrowseNodeAttribute)
        self.pushButton_Browse_SaveDir.clicked.connect(self.BrowseSaveDir)
        self.pushButton_MDA.clicked.connect(self.BrowseAlg_load)
        self.radioButton_node_drop.toggled.connect(self.Update_Nd_Text_State)
        self.radioButton_node_drop_Hub.toggled.connect(self.Update_Nd_Hub_Text_State)
        self.radioButton_edge_perturb.toggled.connect(self.Update_Ep_Text_State)
        self.radioButton_edge_perturb_WD.toggled.connect(self.Update_Ep_WD_Text_State)
        self.radioButton_subgraph_crop.toggled.connect(self.update_Sc_Text_State)
        self.radioButton_attribute_mask.toggled.connect(self.update_Am_Text_State)
        self.radioButton_MDA.toggled.connect(self.enable_pushButton_MDA)
        self.lineEdit_node_drop_ratio.textChanged.connect(self.checkInput_Nd)
        self.lineEdit_node_drop_ratio_Hub.textChanged.connect(self.checkInput_Nd_Hub)
        self.lineEdit_edge_perturb_ratio.textChanged.connect(self.checkInput_Ep)
        self.lineEdit_edge_perturb_ratio_WD.textChanged.connect(self.checkInput_Ep_WD)
        self.lineEdit_subgraph_crop_ratio.textChanged.connect(self.checkInput_Sc)
        self.lineEdit_attribute_mask_ratio.textChanged.connect(self.checkInput_Am)
        self.pushButton_CreateData.clicked.connect(self.CreateData)
        self.pushButton_Help.clicked.connect(self.Help)
        self.Clear.clicked.connect(self.CleaR)



    def BrowseAdjMatrix(self):
        file_name = QFileDialog.getOpenFileName(self, 'Open File', 'materials',
                                                'Adjacency matrix data, with shape (S, N, N) (*.npy)',
                                                options=QtWidgets.QFileDialog.DontUseNativeDialog)
        self.lineEdit_Browse_AdjMatrix.setText(file_name[0])

    def BrowseNodeAttribute(self):
        file_name = QFileDialog.getOpenFileName(self, 'Open File', 'materials',
                                                'Node attribute matrix data, with shape (S, N, D) (*.npy)',
                                                options=QtWidgets.QFileDialog.DontUseNativeDialog)
        self.lineEdit_Browse_NodeAttribute.setText(file_name[0])

    def BrowseSaveDir(self):
        folder_name = QFileDialog.getExistingDirectory(self, 'Select Directory',
                                                       options=QtWidgets.QFileDialog.DontUseNativeDialog)
        self.lineEdit_Browse_SaveDir.setText(folder_name)

    def BrowseAlg_load(self):
        # Please ensure that all dependencies required by the function are properly encapsulated within the pkl file by 'dill' and correctly installed on the device.
        alg_name = QFileDialog.getOpenFileName(self, 'Open File', 'algorithm',
                                                'defined function, with the correct input and output shape (*.pkl)',
                                                options=QtWidgets.QFileDialog.DontUseNativeDialog)
        self.lineEdit_load_MDA.setText(alg_name[0])

    def enable_pushButton_MDA(self, checked):
        if checked:
            self.pushButton_MDA.setEnabled(True)
        else:
            self.pushButton_MDA.setEnabled(False)

    def Update_Nd_Text_State(self, checked):
        if not checked:
            self.lineEdit_node_drop_ratio.setReadOnly(True)
            self.lineEdit_node_drop_ratio.setStyleSheet("color: gray")
        else:
            self.lineEdit_node_drop_ratio.setReadOnly(False)
            self.lineEdit_node_drop_ratio.setStyleSheet("color: black")

    def Update_Nd_Hub_Text_State(self, checked):
        if not checked:
            self.lineEdit_node_drop_ratio_Hub.setReadOnly(True)
            self.lineEdit_node_drop_ratio_Hub.setStyleSheet("color: gray")
        else:
            self.lineEdit_node_drop_ratio_Hub.setReadOnly(False)
            self.lineEdit_node_drop_ratio_Hub.setStyleSheet("color: black")

    def Update_Ep_Text_State(self, checked):
        if not checked:
            self.lineEdit_edge_perturb_ratio.setReadOnly(True)
            self.lineEdit_edge_perturb_ratio.setStyleSheet("color: gray")
        else:
            self.lineEdit_edge_perturb_ratio.setReadOnly(False)
            self.lineEdit_edge_perturb_ratio.setStyleSheet("color: black")

    def Update_Ep_WD_Text_State(self, checked):
        if not checked:
            self.lineEdit_edge_perturb_ratio_WD.setReadOnly(True)
            self.lineEdit_edge_perturb_ratio_WD.setStyleSheet("color: gray")
        else:
            self.lineEdit_edge_perturb_ratio_WD.setReadOnly(False)
            self.lineEdit_edge_perturb_ratio_WD.setStyleSheet("color: black")

    def update_Sc_Text_State(self, checked):
        if not checked:
            self.lineEdit_subgraph_crop_ratio.setReadOnly(True)
            self.lineEdit_subgraph_crop_ratio.setStyleSheet("color: gray")
        else:
            self.lineEdit_subgraph_crop_ratio.setReadOnly(False)
            self.lineEdit_subgraph_crop_ratio.setStyleSheet("color: black")

    def update_Am_Text_State(self, checked):
        if not checked:
            self.lineEdit_attribute_mask_ratio.setReadOnly(True)
            self.lineEdit_attribute_mask_ratio.setStyleSheet("color: gray")
        else:
            self.lineEdit_attribute_mask_ratio.setReadOnly(False)
            self.lineEdit_attribute_mask_ratio.setStyleSheet("color: black")

    def checkInput_Nd(self, text):
        if text.strip() == "":
            return
        try:
            value = float(text)
            if value < 0 or value > 1:
                raise ValueError("Input value must be between 0 and 1.")
        except ValueError as e:
            QMessageBox.critical(self, "Error", str(e))
            self.lineEdit_node_drop_ratio.clear()

    def checkInput_Nd_Hub(self, text):
        if text.strip() == "":
            return
        try:
            value = float(text)
            if value < 0 or value > 1:
                raise ValueError("Input value must be between 0 and 1.")
        except ValueError as e:
            QMessageBox.critical(self, "Error", str(e))
            self.lineEdit_node_drop_ratio_Hub.clear()

    def checkInput_Ep(self, text):
        if text.strip() == "":
            return
        try:
            value = float(text)
            if value < 0 or value > 1:
                raise ValueError("Input value must be between 0 and 1.")
        except ValueError as e:
            QMessageBox.critical(self, "Error", str(e))
            self.lineEdit_edge_perturb_ratio.clear()

    def checkInput_Ep_WD(self, text):
        if text.strip() == "":
            return
        try:
            value = float(text)
            if value < 0 or value > 1:
                raise ValueError("Input value must be between 0 and 1.")
        except ValueError as e:
            QMessageBox.critical(self, "Error", str(e))
            self.lineEdit_edge_perturb_ratio_WD.clear()

    def checkInput_Sc(self, text):
        if text.strip() == "":
            return
        try:
            value = float(text)
            if value < 0 or value > 1:
                raise ValueError("Input value must be between 0 and 1.")
        except ValueError as e:
            QMessageBox.critical(self, "Error", str(e))
            self.lineEdit_subgraph_crop_ratio.clear()

    def checkInput_Am(self, text):
        if text.strip() == "":
            return
        try:
            value = float(text)
            if value < 0 or value > 1:
                raise ValueError("Input value must be between 0 and 1.")
        except ValueError as e:
            QMessageBox.critical(self, "Error", str(e))
            self.lineEdit_attribute_mask_ratio.clear()

    def Load_file(self, file_name):
        data = np.load(file_name)
        return data

    def CreateData(self):
        Adj_file_name = self.lineEdit_Browse_AdjMatrix.text()
        Nod_file_name = self.lineEdit_Browse_NodeAttribute.text()

        if not Adj_file_name or not Nod_file_name:
            QMessageBox.critical(self, "Error", "Input incomplete.")
            return
        adjmat = self.Load_file(Adj_file_name)
        nodeatt = self.Load_file(Nod_file_name)
        if adjmat.ndim != 3 or nodeatt.ndim != 3:
            QMessageBox.critical(self, "Error", "Input shape error. The adjacency matrix and node attribute matrix must be 3-dimensional matrices with shapes (S, N, N) and (S, N, D), respectively, "
                                                "where S is the number of subjects, N is the number of nodes, and D is the dimension of node attributes. "
                                                "Please check your input dimensions.")
            if adjmat.ndim != 3: self.lineEdit_Browse_AdjMatrix.clear()
            if nodeatt.ndim != 3: self.lineEdit_Browse_NodeAttribute.clear()
            return
        if adjmat.shape[0] != nodeatt.shape[0] or adjmat.shape[1] !=nodeatt.shape[1] or adjmat.shape[1] != adjmat.shape[2]:
            QMessageBox.critical(self, "Error", "Input shape error. The adjacency matrix and node attribute matrix must be 3-dimensional matrices with shapes (S, N, N) and (S, N, D), respectively, "
                                                "where S is the number of subjects, N is the number of nodes, and D is the dimension of node attributes. "
                                                "Please check your input dimensions.")
            return

        if self.lineEdit_Browse_SaveDir.text() == "": save_dir = './results'
        else: save_dir = self.lineEdit_Browse_SaveDir.text()

        if self.radioButton_node_drop.isChecked() and self.lineEdit_node_drop_ratio.text() == "":
            self.lineEdit_node_drop_ratio.setText("0.2")
        if self.radioButton_node_drop_Hub.isChecked() and self.lineEdit_node_drop_ratio_Hub.text() == "":
            self.lineEdit_node_drop_ratio_Hub.setText("0.2")
        if self.radioButton_edge_perturb.isChecked() and self.lineEdit_edge_perturb_ratio.text() == "":
            self.lineEdit_edge_perturb_ratio.setText("0.2")
        if self.radioButton_edge_perturb_WD.isChecked() and self.lineEdit_edge_perturb_ratio_WD.text() == "":
            self.lineEdit_edge_perturb_ratio_WD.setText("0.2")
        if self.radioButton_subgraph_crop.isChecked() and self.lineEdit_subgraph_crop_ratio.text() == "":
            self.lineEdit_subgraph_crop_ratio.setText("0.2")
        if self.radioButton_attribute_mask.isChecked() and self.lineEdit_attribute_mask_ratio.text() == "":
            self.lineEdit_attribute_mask_ratio.setText("0.2")

        if self.radioButton_node_drop.isChecked(): node_drop_ratio = float(self.lineEdit_node_drop_ratio.text())
        if self.radioButton_node_drop_Hub.isChecked(): node_drop_ratio = float(self.lineEdit_node_drop_ratio_Hub.text())
        if self.radioButton_edge_perturb.isChecked(): edge_perturbation_ratio = float(self.lineEdit_edge_perturb_ratio.text())
        if self.radioButton_edge_perturb_WD.isChecked(): edge_perturbation_ratio = float(self.lineEdit_edge_perturb_ratio_WD.text())
        if self.radioButton_subgraph_crop.isChecked(): crop_ratio = float(self.lineEdit_subgraph_crop_ratio.text())
        if self.radioButton_attribute_mask.isChecked(): masking_ratio = float(self.lineEdit_attribute_mask_ratio.text())

        if self.radioButton_MDA.isChecked():
            if self.lineEdit_load_MDA.text() == "":
                QMessageBox.critical(self, "Error", "Please load your algorithm. ")
                return

        # Running box
        running_box = QMessageBox(self)
        running_box.setWindowTitle("Please wait")
        running_box.setText("Graph augmenting! Please wait...")
        # running_box.setStandardButtons(QMessageBox.NoButton)
        running_box.show()
        QCoreApplication.processEvents()

        buttonname_lst = [self.radioButton_node_drop, self.radioButton_node_drop_Hub, self.radioButton_edge_perturb,
                          self.radioButton_edge_perturb_WD, self.radioButton_subgraph_crop, self.radioButton_attribute_mask,
                          self.radioButton_MDA]
        for buttonname in buttonname_lst:
            if buttonname.isChecked():
                if buttonname.text() == "Random Node Dropping, with ratio:":
                    self.aug_drop_node(nodeatt, adjmat, save_dir, node_drop_ratio)
                elif buttonname.text() == "Hub-Preserving Node Dropping, with ratio:":
                    self.aug_drop_node_Hub(nodeatt, adjmat, save_dir, node_drop_ratio)
                elif buttonname.text() == "Random Edge Perturbation, with ratio:":
                    self.aug_random_edge(adjmat, save_dir, edge_perturbation_ratio)
                elif buttonname.text() == "Weight-Dependent Edge Removal, with ratio:":
                    self.aug_random_edge_WD(adjmat, save_dir, edge_perturbation_ratio)
                elif buttonname.text() == "Subgraph Cropping, with ratio:":
                    self.aug_subgraph(nodeatt, adjmat, save_dir, crop_ratio)
                elif buttonname.text() == "Attribute Masking, with ratio:":
                    self.aug_random_mask(nodeatt, save_dir, masking_ratio)
                elif buttonname.text() == "Self-Defined Algorithm:":
                    dill.settings['recurse'] = True
                    with open(self.lineEdit_load_MDA.text(), 'rb') as f:
                        alg_fun = dill.load(f)
                    aug_adj, aug_nod = alg_fun(adjmat, nodeatt)
                    if aug_adj is not None: np.save(os.path.join(save_dir, 'save_adjmat_custom.npy'), aug_adj)
                    if aug_nod is not None: np.save(os.path.join(save_dir, 'save_nodeatt_custom.npy'), aug_nod)

        # Finished
        # running_box.reject()
        running_box.close()
        QMessageBox.information(self, "Successful", "Graph augmentation complete! ")


    def delete_row_col(self, input_matrix, drop_list, only_row=False):
        remain_list = [i for i in range(input_matrix.shape[0]) if i not in drop_list]
        out = input_matrix[remain_list, :]
        if only_row:
            return out
        out = out[:, remain_list]
        return out

    def weighted_sampling_without_replacement(self, data, probabilities, k):
        probabilities = probabilities / np.sum(probabilities)
        indices = np.random.choice(len(data), size=k, replace=False, p=probabilities)
        samples = [data[i] for i in indices]
        return samples

    def weighted_sampling_without_replacement2(self, data, probabilities, k):
        probabilities = probabilities / np.sum(probabilities)
        indices = np.random.choice(len(data), size=k, replace=False, p=probabilities)
        return indices

    def restore_symmetric_matrix(self, upper_triangular_elements, n):
        symmetric_matrix = np.zeros((n, n))
        index = 0
        for i in range(0, n):
            for j in range(i + 1, n):
                symmetric_matrix[i][j] = upper_triangular_elements[index]
                symmetric_matrix[j][i] = upper_triangular_elements[index]
                index += 1
        np.fill_diagonal(symmetric_matrix, 1)
        return symmetric_matrix

    def aug_drop_node(self, fea, adj, save_dir, node_drop_ratio):
        r_adj, r_fea = [], []
        for i in range(fea.shape[0]):
            input_fea, input_adj = fea[i], adj[i]
            input_adj = torch.tensor(input_adj)
            input_fea = torch.FloatTensor(input_fea[np.newaxis])
            input_fea = input_fea.squeeze(0)
            node_num = input_fea.shape[0]
            drop_num = int(node_num * node_drop_ratio)
            all_node_list = [i for i in range(node_num)]
            drop_node_list = sorted(random.sample(all_node_list, drop_num))
            aug_input_fea = self.delete_row_col(input_fea, drop_node_list, only_row=True)
            r_fea.append(np.array(aug_input_fea))
            aug_input_adj = self.delete_row_col(input_adj, drop_node_list)
            aug_input_adj = sp.csr_matrix(np.matrix(aug_input_adj))
            r_adj.append(np.array(aug_input_adj.todense()))
        np.save(os.path.join(save_dir, 'save_nodeatt_node_dropping_ratio_' + str(node_drop_ratio) + '.npy'),
                np.stack(r_fea, axis=0))
        np.save(os.path.join(save_dir, 'save_adjmat_node_dropping_ratio_' + str(node_drop_ratio) + '.npy'),
                np.stack(r_adj, axis=0))

    def aug_drop_node_Hub(self, fea, adj, save_dir, node_drop_ratio):
        r_adj, r_fea = [], []
        for i in range(fea.shape[0]):
            input_fea, input_adj = fea[i], adj[i]
            input_fea = torch.FloatTensor(input_fea[np.newaxis])
            DC = np.sum(abs(input_adj), axis=1).tolist()
            input_fea = input_fea.squeeze(0)
            node_num = input_adj.shape[0]
            all_node_list = [i for i in range(node_num)]
            k = int(len(all_node_list) * (1 - node_drop_ratio))
            selected_roi = sorted(self.weighted_sampling_without_replacement(all_node_list, DC, k))
            drop_node_list = sorted(list(set(all_node_list) - set(selected_roi)))
            aug_input_fea = self.delete_row_col(input_fea, drop_node_list, only_row=True)
            aug_input_adj = self.delete_row_col(input_adj, drop_node_list)
            r_fea.append(np.array(aug_input_fea))
            r_adj.append(np.array(aug_input_adj))
        np.save(os.path.join(save_dir, 'save_nodeatt_node_dropping_hubpre_ratio_' + str(node_drop_ratio) + '.npy'),
                np.stack(r_fea, axis=0))
        np.save(os.path.join(save_dir, 'save_adjmat_node_dropping_hubpre_ratio_' + str(node_drop_ratio) + '.npy'),
                np.stack(r_adj, axis=0))

    def aug_random_edge(self, adj, save_dir, edge_perturbation_ratio):
        r_adj = []
        for input_adj in adj:
            percent = edge_perturbation_ratio / 2
            row_idx, col_idx = input_adj.nonzero()
            index_list = []
            for i in range(len(row_idx)):
                index_list.append((row_idx[i], col_idx[i]))
            single_index_list = []
            for i in list(index_list):
                single_index_list.append(i)
                index_list.remove((i[1], i[0]))
            edge_num = int(len(row_idx) / 2)
            add_drop_num = int(edge_num * percent / 2)
            aug_adj = copy.deepcopy(input_adj)
            edge_idx = [i for i in range(edge_num)]
            drop_idx = random.sample(edge_idx, add_drop_num)
            for i in drop_idx:
                aug_adj[single_index_list[i][0]][single_index_list[i][1]] = 0
                aug_adj[single_index_list[i][1]][single_index_list[i][0]] = 0
            node_num = input_adj.shape[0]
            l = [(i, j) for i in range(node_num) for j in range(i)]
            add_list = random.sample(l, add_drop_num)
            for i in add_list:
                aug_adj[i[0]][i[1]] = 1
                aug_adj[i[1]][i[0]] = 1
            aug_adj = np.array(sp.csr_matrix(np.matrix(aug_adj)).todense())
            r_adj.append(aug_adj)
        np.save(os.path.join(save_dir, 'save_adjmat_edge_perturbation_ratio_' + str(edge_perturbation_ratio) + '.npy'),
                np.stack(r_adj, axis=0))

    def aug_random_edge_WD(self, adj, save_dir, edge_perturbation_ratio):
        r_adj = []
        for input_adj in adj:
            upper = input_adj[np.triu_indices(input_adj.shape[0], 1)]
            k = int(upper.shape[0] * (1 - edge_perturbation_ratio))
            selected_idx = self.weighted_sampling_without_replacement2(upper, abs(upper), k)
            all_idx = [i for i in range(upper.shape[0])]
            removed_idx = sorted(list(set(all_idx) - set(selected_idx)))
            for i in range(len(removed_idx)):
                idx = removed_idx[i]
                upper[idx] = 0
            aug_adj = self.restore_symmetric_matrix(upper, input_adj.shape[0])
            r_adj.append(aug_adj)
        np.save(os.path.join(save_dir, 'save_adjmat_edge_remove_ratio_' + str(edge_perturbation_ratio) + '.npy'),
                np.stack(r_adj, axis=0))

    def aug_subgraph(self, fea, adj, save_dir, crop_ratio):
        r_adj, r_fea = [], []
        for i in range(fea.shape[0]):
            input_fea, input_adj = fea[i], adj[i]
            input_adj = torch.tensor(input_adj)
            input_fea = torch.FloatTensor(input_fea[np.newaxis])
            input_fea = input_fea.squeeze(0)
            node_num = input_fea.shape[0]
            all_node_list = [i for i in range(node_num)]
            s_node_num = int(node_num * (1 - crop_ratio))
            center_node_id = random.randint(0, node_num - 1)
            sub_node_id_list = [center_node_id]
            all_neighbor_list = []
            for ii in range(s_node_num - 1):
                all_neighbor_list += torch.nonzero(input_adj[sub_node_id_list[ii]], as_tuple=False).squeeze(1).tolist()
                all_neighbor_list = list(set(all_neighbor_list))
                new_neighbor_list = [n for n in all_neighbor_list if not n in sub_node_id_list]
                if len(new_neighbor_list) != 0:
                    new_node = random.sample(new_neighbor_list, 1)[0]
                    sub_node_id_list.append(new_node)
                else:
                    break
            drop_node_list = sorted([ii for ii in all_node_list if not ii in sub_node_id_list])
            aug_input_fea = self.delete_row_col(input_fea, drop_node_list, only_row=True)
            aug_input_adj = self.delete_row_col(input_adj, drop_node_list)
            aug_input_adj = np.array(sp.csr_matrix(np.matrix(aug_input_adj)).todense())
            r_adj.append(aug_input_adj)
            r_fea.append(np.array(aug_input_fea))
        np.save(os.path.join(save_dir, 'save_nodeatt_subgraph_ratio_' + str(crop_ratio) + '.npy'),
                np.stack(r_fea, axis=0))
        np.save(os.path.join(save_dir, 'save_adjmat_subgraph_ratio_' + str(crop_ratio) + '.npy'),
                np.stack(r_adj, axis=0))

    def aug_random_mask(self, fea, save_dir, masking_ratio):
        r_fea = []
        for input_feature in fea:
            input_feature = torch.FloatTensor(input_feature[np.newaxis])
            node_num = input_feature.shape[1]
            mask_num = int(node_num * masking_ratio)
            node_idx = [i for i in range(node_num)]
            mask_idx = random.sample(node_idx, mask_num)
            aug_feature = copy.deepcopy(input_feature)
            zeros = torch.zeros_like(aug_feature[0][0])
            for j in mask_idx:
                aug_feature[0][j] = zeros
            r_fea.append(np.array(aug_feature.squeeze()))
        np.save(os.path.join(save_dir, 'save_nodeatt_masking_ratio_' + str(masking_ratio) + '.npy'),
                np.stack(r_fea, axis=0))

    def Help(self):
        QMessageBox.about(self,
            "Help Info",
            "<p>  This module is for brain network/graph augmentation. </p>"
            "<p>- Input adjacency matrix should be of size (S, N, N). </p>"
            "<p>- Input node attribute should be of size (S, N, D). </p>"
            "<p>- Hyper-parameters of all augmentation algorithms should be between 0 and 1. </p>"
            "<p>  Symbol meaning: S is the number of subjects, N is the number of brain regions/nodes, D is the dimension of node attributes. </p>"
        )

    def CleaR(self):
        self.lineEdit_Browse_AdjMatrix.clear()
        self.lineEdit_Browse_NodeAttribute.clear()
        self.lineEdit_node_drop_ratio.clear()
        self.lineEdit_edge_perturb_ratio.clear()
        self.lineEdit_subgraph_crop_ratio.clear()
        self.lineEdit_attribute_mask_ratio.clear()
        self.lineEdit_Browse_SaveDir.clear()
        self.lineEdit_load_MDA.clear()
        self.lineEdit_node_drop_ratio_Hub.clear()
        self.lineEdit_edge_perturb_ratio_WD.clear()

